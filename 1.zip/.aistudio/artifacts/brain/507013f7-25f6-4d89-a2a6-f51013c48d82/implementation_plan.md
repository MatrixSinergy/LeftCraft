# LetraCraft — Juego de Inglés Letra por Letra

Aplicación educativa interactiva con estética de juego vibrante para aprender vocabulario y frases en inglés desde español, construyendo cada palabra y frase letra por letra mediante bloques táctiles seleccionables en pantalla, con validación inmediata por letra y un sistema de pistas inteligentes en niveles progresivos.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Se han integrado todas las preferencias confirmadas en la fase de preguntas para definir la mecánica central, el apoyo pedagógico y la dirección visual del juego.

- **Mecánica de entrada confirmada**: Solo bloques de letras seleccionables en pantalla (tablero táctil interactivo con fichas de letra presionables y distractores fonéticos, sin dependencia de teclado físico).
- **Apoyo de aprendizaje confirmado**: Pistas inteligentes multinivel y corrección inmediata por cada letra seleccionada (explicación contextual ante errores comunes de hispanohablantes y retroalimentación instantánea).
- **Estilo visual confirmado**: Juego educativo vibrante y expresivo, con tipografía limpia, alto contraste, tarjetas táctiles con relieve sutil y disciplina de color 60-30-10.
- **Decisión por defecto recomendada (Persistencia y Audio)**: El progreso (mundos desbloqueados, racha, precisión y palabras falladas para repaso) se guardará localmente en el navegador (`localStorage`) sin exigir registro, y se incluirá pronunciación en inglés mediante síntesis de voz nativa del navegador (`Web Speech API`) más efectos de sonido suaves (`Web Audio API`) con interruptor de silencio.

---

## 1. Overview & Core Concept

- **Qué hace**: Permite practicar inglés formando palabras individuales y frases completas letra por letra a partir de un banco interactivo de fichas en pantalla, partiendo siempre de su significado en español y un contexto de uso real.
- **Público objetivo**: Estudiantes hispanohablantes (niveles A1 a B1) que buscan internalizar la ortografía real del inglés, evitar confusiones fonéticas frecuentes y ganar fluidez construyendo frases prácticas de manera lúdica.
- **Valor principal**: Combina el aprendizaje activo de la ortografía inglesa con retroalimentación inmediata en el instante exacto de cada error, transformando fallos comunes (como letras mudas, dobles consonantes o vocales engañosas) en micro-lecciones memorables.

---

## 2. User Experience & Visual Design

### Flujos Principales de Usuario

1. **Pantalla de Mundos y Selección (`Mundos`)**:
   - El usuario visualiza 4 mundos temáticos progresivos: *Palabras Esenciales (A1)*, *Frases Cotidianas (A1–A2)*, *Viajes y Ciudad (A2)* y *Conversación Natural (B1)*, cada uno con su progreso completado y un botón claro para jugar.
   - Puede filtrar rápidamente por tipo de reto (*Todo*, *Solo Palabras*, *Solo Frases*) o saltar directo a la sesión activa desde el botón principal del encabezado.
2. **Escenario Activo de Juego (`Práctica`)**:
   - **Zona de Estímulo**: Muestra la palabra o frase en español, su categoría/nivel como texto limpio con separadores (`·`), un botón de audio para escuchar la pronunciación en inglés y una pista contextual inicial opcional.
   - **Tablero de Casillas por Letra**: Cada letra de la palabra o frase aparece como una casilla táctil ordenada por palabras (los espacios entre palabras se resuelven automáticamente con separación visual clara para no interrumpir el ritmo). La casilla activa resalta con un indicador visual y cursor claro.
   - **Banco de Fichas Seleccionables en Pantalla**: Cuadrícula de bloques de letras (`≥ 48px` de área táctil) que mezcla las letras exactas de la palabra o frase con 2 a 4 distractores fonéticos inteligentes (ej. `i/e`, `b/v`, `c/k/s`).
   - **Corrección Inmediata por Letra**:
     - *Acierto*: La ficha encaja con animación ágil (`≤ 180ms`), tono esmeralda con icono de verificación, sonido breve ascendente y avance automático a la siguiente letra.
     - *Error*: La ficha vibra suavemente (`≤ 200ms`), muestra un mensaje explícito no dependiente solo del color (icono de alerta + regla rápida, ej. *"Error en posición 3: en inglés 'coffee' duplica la 'f' y la 'e'"*), y registra el término en la cola de repaso.
   - **Pistas Inteligentes Multinivel**:
     - *Nivel 1 — Pista Ortográfica*: Explica un patrón clave de la palabra o frase actual (letras mudas, sonidos vocálicos o estructura gramatical).
     - *Nivel 2 — Reducir Opciones*: Atenúa o desactiva las fichas distractoras del banco para dejar solo las letras útiles.
     - *Nivel 3 — Revelar Siguiente Letra*: Completa automáticamente la casilla activa con un marcador claro de pista aplicada para evitar bloqueos.
3. **Resumen de Ronda y Repaso (`Repaso` y `Progreso`)**:
   - Al completar una ronda de ejercicios, una vista de resumen muestra precisión, racha máxima, tiempo o puntos de experiencia y las palabras con errores para reforzarlas de inmediato.
   - La sección `Repaso` reúne automáticamente las palabras o frases donde el jugador cometió errores o usó pistas de revelación, permitiendo practicarlas en una ronda enfocada.

### Identidad Visual y Tema

- **Dirección estética**: Juego educativo táctil, luminoso y expresivo, inspirado en juegos de fichas de letras modernos con alto rigor de legibilidad y cero saturación visual innecesaria.
- **Paleta de color (Regla 60-30-10)**:
  - *60% Lienzo principal*: Fondo neutro limpio marfil frío (`#F8FAFC`) con superficie de tablero elevada en blanco puro (`#FFFFFF`).
  - *30% Superficies estructurales*: Paneles secundarios en pizarra suave (`#F1F5F9`), bordes finos (`#E2E8F0`) y texto principal en tinta oscura (`#0F172A`) con contraste AA/AAA.
  - *10% Acentos de juego y estado*: Índigo vibrante (`#4F46E5`) para acciones principales y casilla activa; Ámbar dorado (`#D97706`) para rachas y pistas; Esmeralda (`#059669`) para aciertos con icono; Coral (`#E11D48`) para errores inmediatos con icono y texto explicativo.
- **Tipografía y Jerarquía**:
  - *Títulos y fichas de letras*: `Bricolage Grotesque` (geométrica, expresiva y con gran apertura en caracteres individuales para distinguir claramente `I`, `l`, `O`, `0`).
  - *Cuerpo y explicaciones*: `Plus Jakarta Sans` para máxima claridad en traducciones y pistas en español.
  - *Métricas y contadores*: `JetBrains Mono` con `tabular-nums` para puntajes, precisión y contadores de letras.
- **Estructura de Navegación y Contención**:
  - Barra superior estricta de 3 zonas en una sola línea: Marca (`LetraCraft`), 4 enlaces limpios (`Mundos`, `Práctica`, `Repaso`, `Progreso`) y 1 botón de acción principal (`Jugar Ahora`).
  - Metadatos sin píldoras estáticas: la dificultad, categoría y contadores usan texto limpio separado por puntos medios (`·`).
  - Ilustraciones personalizadas generadas para las portadas de los 4 mundos temáticos, acompañadas de contenedores de respaldo estilizados.

### Retroalimentación Interactiva y Movimiento

- Transiciones compositor-only (`transform`, `opacity`) por debajo de `200ms` para el encaje de fichas y vibración lateral de error.
- Soporte completo de `prefers-reduced-motion` y foco visible (`focus-visible`) en todas las fichas seleccionables.
- Sonidos sintetizados ligeros (acierto, error suave, palabra completada, victoria de ronda) más pronunciación automática o bajo demanda al completar cada palabra o frase.

---

## 3. Key Product Decisions & Trade-Offs

- **Decisión 1: Modo de bloques de letras con separación automática de palabras en frases**
  - *Enfoque elegido*: Al practicar frases de varias palabras, los espacios entre palabras se muestran como separadores visuales claros y el cursor salta automáticamente de la última letra de una palabra a la primera letra de la siguiente.
  - *Por qué*: Pulsar una tecla de espacio como si fuera una ficha rompe el flujo lúdico y no aporta aprendizaje ortográfico; enfocar cada toque en letras reales acelera el dominio de la frase.
  - *Alternativas consideradas*: Incluir fichas de espacio en el banco (descartado por fricción innecesaria en pantalla táctil).
- **Decisión 2: Validación inmediata letra por letra vs. validación al final**
  - *Enfoque elegido*: Validar cada ficha en el instante en que se toca, impidiendo avanzar sobre una letra incorrecta y mostrando una micro-pista inmediata.
  - *Por qué*: Cumple con la preferencia de corrección inmediata por letra y evita que el alumno memorice visualmente una palabra mal escrita antes de corregirla.
  - *Alternativas consideradas*: Permitir llenar toda la palabra y revisar al enviar (descartado porque retrasa la corrección ortográfica).
- **Decisión 3: Banco de fichas inteligente con distractores fonéticos**
  - *Enfoque elegido*: El banco incluye exactamente las instancias de letras necesarias para el reto actual más 2 a 4 distractores seleccionados según errores típicos entre español e inglés (vocales intercambiables, consonantes mudas o dobles), aceptando cualquier instancia equivalente de una misma letra repetida.
  - *Por qué*: Garantiza que no haya ambigüedad frustrante cuando una palabra repite letras (como las dos `o` de *Good*), mientras entrena la discriminación visual y fonética.
  - *Alternativas consideradas*: Mostrar el alfabeto completo de 26 teclas estilo QWERTY (descartado porque se asemeja demasiado a un teclado estándar y reduce la mecánica de bloques seleccionables).
- **Decisión 4: Persistencia local sin fricción (`localStorage`)**
  - *Enfoque elegido*: Guardar mundos completados, racha diaria, precisión histórica y cola de repaso directamente en `localStorage` con opción de reinicio controlado.
  - *Por qué*: Permite iniciar el juego en menos de un segundo sin pantallas de inicio de sesión ni infraestructura externa innecesaria.
  - *Alternativas consideradas*: Base de datos en la nube con autenticación (innecesaria dado que no se solicitaron cuentas multi-dispositivo).

---

## 4. Technical Architecture & Data Strategy

### Diagrama de Arquitectura del Sistema

```text
┌──────────────────────────────────────────────────────────────────────┐
│                         LetraCraft App Shell                         │
│  ┌──────────────┐   ┌───────────────────────────────┐   ┌──────────┐ │
│  │  Top Bar     │   │      Persistent Store         │   │  Audio   │ │
│  │ (3 zonas)    │◄──┤ (localStorage: XP, racha,     │──►│  Engine  │ │
│  └──────┬───────┘   │  mundos, cola de repaso)      │   │(WebAudio │ │
│         │           └──────────────┬────────────────┘   │ + Speech)│ │
│         ▼                          │                    └──────────┘ │
│  ┌─────────────────────────────────┴──────────────────────────────┐  │
│  │                 View & Game State Machine                      │  │
│  │   ('WORLDS' | 'PLAYING' | 'ROUND_SUMMARY' | 'REVIEW' | 'STATS')│  │
│  └──────┬──────────────────┬──────────────────────┬───────────────┘  │
│         │                  │                      │                  │
│         ▼                  ▼                      ▼                  │
│  ┌─────────────┐   ┌──────────────────┐   ┌───────────────────────┐  │
│  │ Worlds Grid │   │ Active Play      │   │ Review & Progress     │  │
│  │ & Filters   │   │ Stage            │   │ Dashboard             │  │
│  └─────────────┘   │  ├─ Prompt & TTS │   │  ├─ Mistake Queue     │  │
│                    │  ├─ Letter Slots │   │  ├─ Accuracy & Streak │  │
│                    │  ├─ Smart Hints  │   │  └─ Mastered Words    │  │
│                    │  └─ Tile Bank    │   └───────────────────────┘  │
│                    └──────────────────┘                              │
└──────────────────────────────────────────────────────────────────────┘
```

### Modelo de Datos y Estado

- **Curriculum (`World` & `ChallengeItem`)**:
  - Cada `World` agrupa retos curados con nivel (`A1`, `A2`, `B1`), descripción y temática visual.
  - Cada `ChallengeItem` contiene: `id`, `type` (`'word' | 'phrase'`), `english` (texto objetivo normalizado), `spanish` (significado natural), `phonetic` (guía aproximada legible), `contextExample` (frase corta de ejemplo), `smartTip` (explicación ortográfica específica para hispanohablantes) y `distractors` (letras trampa curadas).
- **Estado de Ronda (`ActiveRoundState`)**:
  - `currentIndex`: ítem activo dentro de la ronda.
  - `cursorIndex`: índice de la letra actual esperada (omitiendo espacios).
  - `filledSlots`: arreglo con estado de cada carácter (`pending`, `correct`, `hinted`).
  - `tilePool`: arreglo de fichas generadas (`id`, `letter`, `isDistractor`, `status`: `'available' | 'used' | 'eliminated'`).
  - `hintTier`: nivel de pista activado en el ítem actual (`0..3`).
  - `feedbackBanner`: estado de retroalimentación inmediata (`idle`, `error` con mensaje contextual específico, `success`).
- **Progreso Persistente (`PlayerProgress`)**:
  - `xp`, `currentStreak`, `bestStreak`, `totalAttempts`, `correctFirstTry`, `completedChallengeIds`, `reviewQueueIds` y `soundEnabled`.

### Mapeo Interactivo de Componentes y Manejadores

- **Selector de Mundos y Filtros**: Filtrar por *Todos / Palabras / Frases* actualiza instantáneamente la lista visible; seleccionar un mundo inicia `ActiveRoundState` con los retos filtrados y transiciona a `'PLAYING'`.
- **Banco de Fichas (`TileBank`)**: Cada ficha ejecuta `handleTileTap(tileId)`. Si `tile.letter` coincide con la letra esperada en `cursorIndex`, marca esa ficha como `'used'`, rellena la casilla correspondiente, reproduce el sonido de acierto y avanza el cursor (o finaliza la palabra pronunciándola en inglés). Si no coincide, dispara animación de rechazo en la ficha, muestra la regla ortográfica contextual en el banner de corrección inmediata, incrementa el contador de errores del ítem y lo añade a `reviewQueueIds`.
- **Panel de Pistas Inteligentes (`SmartHintBar`)**: Ejecuta `handleRequestHint(tier)` de forma progresiva: Nivel 1 despliega la regla ortográfica; Nivel 2 marca las fichas distractoras como `'eliminated'` (deshabilitadas visualmente); Nivel 3 busca una ficha disponible que coincida con la letra del `cursorIndex` y la coloca automáticamente en la casilla como `'hinted'`.
- **Cola de Repaso y Estadísticas (`Review` / `Stats`)**: Permite lanzar una ronda de repaso directo con los ítems fallados (eliminándolos de la cola al completarlos sin errores) y reiniciar el progreso de forma segura mediante confirmación dentro de la interfaz.
