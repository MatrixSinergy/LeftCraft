import { useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  Filter,
  Lightbulb,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { ActiveRoundState, LetterSlot } from '../types/game';
import { speakEnglish } from '../utils/audio';
import { ProgressRing, RoundStepBar } from './Charts';

interface PlayStageProps {
  round: ActiveRoundState;
  currentStreak: number;
  accuracyPercent: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onExitToWorlds: () => void;
  onTapTile: (tileId: string) => void;
  onRequestHint: (tier: 1 | 2 | 3) => void;
  onNextChallenge: () => void;
}

export function PlayStage({
  round,
  currentStreak,
  accuracyPercent,
  soundEnabled,
  onToggleSound,
  onExitToWorlds,
  onTapTile,
  onRequestHint,
  onNextChallenge,
}: PlayStageProps) {
  const [showEnglish, setShowEnglish] = useState(true);

  const item = round.items[round.currentIndex];
  if (!item) return null;

  const wordGroups: LetterSlot[][] = [];
  for (const slot of round.slots) {
    if (slot.isSpace) continue;
    if (!wordGroups[slot.wordIndex]) {
      wordGroups[slot.wordIndex] = [];
    }
    wordGroups[slot.wordIndex].push(slot);
  }

  const totalLetters = round.slots.filter(
    (s) => !s.isSpace && !s.isSeparator
  ).length;
  const filledCount = round.slots.filter(
    (s) => !s.isSpace && !s.isSeparator && s.status !== 'pending'
  ).length;
  const letterPercent =
    totalLetters > 0 ? Math.round((filledCount / totalLetters) * 100) : 0;

  const completedStatuses = round.results.map((r) =>
    r.mistakes === 0 && !r.usedRevealHint ? 'clean' : 'assisted'
  );
  const currentAssisted = round.currentMistakes > 0 || round.currentRevealUsed;
  const displayEnglish = item.displayEnglish ?? item.english.toLowerCase();

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Frosted HUD Header */}
      <div className="bg-white/90 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl p-4 sm:px-6 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onExitToWorlds}
              className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
            >
              <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Volver</span>
            </button>
            <div className="text-sm font-semibold text-slate-900 truncate">
              {round.title}
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs font-medium text-slate-600">
            <span className="font-mono tabular-nums">
              {round.currentIndex + 1}/{round.items.length}
            </span>
            <span aria-hidden="true" className="text-slate-300">
              ·
            </span>
            <span className="font-mono tabular-nums">Racha {currentStreak}</span>
            <span aria-hidden="true" className="text-slate-300">
              ·
            </span>
            <span className="font-mono tabular-nums">{accuracyPercent}%</span>
            <button
              type="button"
              onClick={onToggleSound}
              aria-label={soundEnabled ? 'Silenciar efectos' : 'Activar sonido'}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 min-h-[36px] text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
            >
              {soundEnabled ? (
                <Volume2 className="w-3.5 h-3.5 text-indigo-600" aria-hidden="true" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
              )}
              <span className="hidden sm:inline">
                {soundEnabled ? 'Sonido' : 'Silencio'}
              </span>
            </button>
          </div>
        </div>

        {/* Segmented Round Step Progress Bar */}
        <RoundStepBar
          total={round.items.length}
          currentIndex={round.currentIndex}
          completedStatuses={completedStatuses}
          currentCompleted={round.itemCompleted}
          currentAssisted={currentAssisted}
        />
      </div>

      {/* Dominant Game Stage Board */}
      <section className="bg-white/95 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-8 space-y-6">
        {/* Stimulus Header with Letter Ring */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div className="flex items-start gap-4">
            <ProgressRing
              percent={letterPercent}
              size={58}
              strokeWidth={6}
              colorClass={
                round.itemCompleted ? 'text-emerald-600' : 'text-indigo-600'
              }
              label={`${filledCount}/${totalLetters}`}
            />

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
                <span>{item.type === 'word' ? 'Palabra' : 'Frase'}</span>
                <span aria-hidden="true">·</span>
                <span>Nivel {item.level}</span>
                <span aria-hidden="true">·</span>
                <span>{item.category}</span>
              </div>

              <h1 className="font-display text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <span>{item.spanish}</span>
                {showEnglish && (
                  <>
                    <span
                      aria-hidden="true"
                      className="text-slate-300 font-normal"
                    >
                      —
                    </span>
                    <span className="text-indigo-700">{displayEnglish}</span>
                  </>
                )}
              </h1>

              {item.phonetic && (
                <p className="text-xs sm:text-sm text-slate-500 font-mono">
                  Pronunciación guía: {item.phonetic}
                </p>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start shrink-0">
            <button
              type="button"
              onClick={() => setShowEnglish((prev) => !prev)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 min-h-[42px] text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
            >
              {showEnglish ? (
                <>
                  <EyeOff className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Ocultar inglés</span>
                </>
              ) : (
                <>
                  <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Mostrar inglés</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => speakEnglish(displayEnglish, true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] text-xs sm:text-sm font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-xl hover:bg-indigo-100 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
            >
              <Volume2 className="w-4 h-4" aria-hidden="true" />
              <span>Escuchar inglés</span>
            </button>
          </div>
        </div>

        {/* Letter Slots Board (Grouped by Word) */}
        <div
          aria-label="Tablero de letras por completar"
          className="py-5 px-3 sm:px-6 bg-slate-50/90 border border-slate-200/70 rounded-2xl flex flex-wrap items-center justify-center gap-x-6 gap-y-4"
        >
          {wordGroups.map((group, gIdx) => (
            <div
              key={gIdx}
              className="flex flex-wrap sm:flex-nowrap items-center justify-center gap-1.5 sm:gap-2"
            >
              {group.map((slot) => {
                if (slot.isSeparator) {
                  return (
                    <div
                      key={slot.index}
                      aria-hidden="true"
                      className="w-4 h-12 sm:h-14 flex items-center justify-center font-display font-bold text-2xl text-slate-500 select-none"
                    >
                      {slot.char}
                    </div>
                  );
                }

                const isActive =
                  !round.itemCompleted && slot.index === round.cursorIndex;
                const isFilled = slot.status !== 'pending';
                const isHinted = slot.status === 'hinted';

                return (
                  <div
                    key={slot.index}
                    aria-label={
                      isFilled
                        ? `Letra ${slot.char}`
                        : isActive
                        ? 'Casilla actual por completar'
                        : 'Casilla pendiente'
                    }
                    className={`w-10 h-12 sm:w-12 sm:h-14 rounded-xl flex flex-col items-center justify-center font-display font-extrabold text-xl sm:text-2xl select-none transition-all duration-150 ${
                      slot.status === 'correct'
                        ? 'bg-emerald-50 border-2 border-emerald-500 text-emerald-900 animate-tile-snap'
                        : isHinted
                        ? 'bg-amber-50 border-2 border-amber-500 text-amber-900 animate-tile-snap'
                        : isActive
                        ? 'bg-white border-2 border-indigo-600 text-indigo-700 shadow-sm'
                        : 'bg-white border border-dashed border-slate-300 text-transparent'
                    }`}
                  >
                    <span>{isFilled ? slot.char : ''}</span>
                    {isActive && (
                      <span
                        aria-hidden="true"
                        className="w-5 h-1 rounded-full bg-indigo-600 mt-1"
                      />
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* Immediate Per-Letter Correction / Success / Hint Banner */}
        <div className="min-h-[76px] flex items-center">
          {round.feedback.kind === 'error' && (
            <div
              role="alert"
              className="w-full p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-950 flex items-start gap-3"
            >
              <AlertCircle
                className="w-5 h-5 text-rose-600 shrink-0 mt-0.5"
                aria-hidden="true"
              />
              <div className="text-sm leading-relaxed">
                <span className="font-bold">Corrección inmediata: </span>
                <span>{round.feedback.message}</span>
              </div>
            </div>
          )}

          {round.feedback.kind === 'hint' && (
            <div
              role="status"
              className="w-full p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 flex items-start gap-3"
            >
              <Lightbulb
                className="w-5 h-5 text-amber-600 shrink-0 mt-0.5"
                aria-hidden="true"
              />
              <div className="text-sm leading-relaxed">
                <span className="font-bold">Pista inteligente: </span>
                <span>{round.feedback.message}</span>
              </div>
            </div>
          )}

          {round.feedback.kind === 'success' && (
            <div
              role="status"
              className="w-full p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
            >
              <div className="flex items-start gap-3">
                <CheckCircle2
                  className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <div className="text-sm space-y-0.5">
                  <div className="font-bold">{round.feedback.message}</div>
                  {item.contextExample ? (
                    <div className="text-emerald-900">
                      <span className="font-semibold">Ejemplo: </span>
                      {item.contextExample} —{' '}
                      <span className="text-emerald-800">
                        {item.contextTranslation}
                      </span>
                    </div>
                  ) : (
                    <div className="text-emerald-900">{item.smartTip}</div>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={onNextChallenge}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[44px] bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2"
              >
                <span>
                  {round.currentIndex + 1 < round.items.length
                    ? 'Siguiente reto'
                    : 'Ver resumen'}
                </span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          )}

          {round.feedback.kind === 'idle' && (
            <div className="w-full p-4 rounded-xl bg-slate-50 border border-slate-200/80 text-slate-600 text-sm">
              {round.feedback.message}
            </div>
          )}
        </div>

        {/* Smart Hint Controls (3 Tiers) */}
        {!round.itemCompleted && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
            <span className="text-xs font-semibold text-slate-500">
              Pistas inteligentes:
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => onRequestHint(1)}
                disabled={round.hintTier >= 1}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600 ${
                  round.hintTier >= 1
                    ? 'bg-amber-50 border-amber-200 text-amber-800 cursor-default'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-amber-50 hover:border-amber-300'
                }`}
              >
                <Lightbulb className="w-3.5 h-3.5" aria-hidden="true" />
                <span>1. Regla ortográfica</span>
              </button>

              <button
                type="button"
                onClick={() => onRequestHint(2)}
                disabled={round.hintTier >= 2}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600 ${
                  round.hintTier >= 2
                    ? 'bg-amber-50 border-amber-200 text-amber-800 cursor-default'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-amber-50 hover:border-amber-300'
                }`}
              >
                <Filter className="w-3.5 h-3.5" aria-hidden="true" />
                <span>2. Filtrar distractores</span>
              </button>

              <button
                type="button"
                onClick={() => onRequestHint(3)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] text-xs font-semibold rounded-xl border bg-white border-slate-200 text-slate-700 hover:bg-amber-50 hover:border-amber-300 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600"
              >
                <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                <span>3. Revelar letra</span>
              </button>
            </div>
          </div>
        )}

        {/* On-Screen Selectable Letter Tile Bank */}
        <div className="bg-slate-100/90 border border-slate-200/80 rounded-2xl p-4 sm:p-6">
          <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-3">
            {round.tiles.map((tile) => {
              const isUsed = tile.status === 'used';
              const isEliminated = tile.status === 'eliminated';
              const isShaking = round.shakingTileId === tile.id;
              const isDisabled =
                isUsed || isEliminated || round.itemCompleted;

              return (
                <button
                  key={tile.id}
                  type="button"
                  disabled={isDisabled}
                  onClick={() => onTapTile(tile.id)}
                  aria-label={`Letra ${tile.letter}${
                    isUsed
                      ? ', ya colocada'
                      : isEliminated
                      ? ', descartada'
                      : ''
                  }`}
                  className={`min-w-[48px] h-[52px] sm:min-w-[54px] sm:h-[58px] px-3 rounded-xl font-display font-extrabold text-xl sm:text-2xl flex items-center justify-center select-none transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2 ${
                    isUsed
                      ? 'bg-slate-200/70 border border-slate-200 text-slate-400 opacity-25 cursor-default'
                      : isEliminated
                      ? 'bg-slate-200/60 border border-slate-200 text-slate-400 opacity-35 line-through cursor-not-allowed'
                      : isShaking
                      ? 'bg-rose-50 border-2 border-rose-500 border-b-4 text-rose-700 animate-tile-shake'
                      : round.itemCompleted
                      ? 'bg-white border border-slate-200 text-slate-400 opacity-50 cursor-default'
                      : 'bg-white border border-slate-300 border-b-4 text-slate-900 hover:border-indigo-400 hover:-translate-y-0.5 active:translate-y-0.5 active:border-b-2 cursor-pointer'
                  }`}
                >
                  {tile.letter}
                </button>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
