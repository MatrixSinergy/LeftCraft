import { useState } from 'react';
import {
  BarChart3,
  Compass,
  Layers,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  Play,
  RotateCcw,
  Search,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { ALL_CHALLENGES, WORLDS } from '../data/curriculum';
import { AppView, PlayerProgress } from '../types/game';

interface SidebarNavProps {
  activeView: AppView;
  progress: PlayerProgress;
  hasActiveRound: boolean;
  searchQuery: string;
  onSearchSubmit: (query: string) => void;
  onNavigate: (view: AppView) => void;
  onQuickPlay: () => void;
  onStartWorld: (worldId: string) => void;
  onToggleSound: () => void;
}

export function SidebarNav({
  activeView,
  progress,
  hasActiveRound,
  searchQuery,
  onSearchSubmit,
  onNavigate,
  onQuickPlay,
  onStartWorld,
  onToggleSound,
}: SidebarNavProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [localSearch, setLocalSearch] = useState(searchQuery);

  const completedSet = new Set(progress.completedChallengeIds);

  const primaryItems: {
    view: AppView;
    label: string;
    count?: number;
    iconBg: string;
    icon: typeof Compass;
  }[] = [
    {
      view: 'WORLDS',
      label: 'Mundos',
      count: WORLDS.length,
      iconBg: 'bg-sky-500',
      icon: Compass,
    },
    {
      view: 'VOCAB_1000',
      label: '1000 Palabras',
      count: ALL_CHALLENGES.length,
      iconBg: 'bg-indigo-500',
      icon: Layers,
    },
    {
      view: 'PLAYING',
      label: 'Práctica',
      iconBg: 'bg-emerald-500',
      icon: Play,
    },
    {
      view: 'REVIEW',
      label: 'Repaso',
      count: progress.reviewQueueIds.length,
      iconBg: 'bg-amber-500',
      icon: RotateCcw,
    },
    {
      view: 'STATS',
      label: 'Progreso',
      iconBg: 'bg-violet-500',
      icon: BarChart3,
    },
  ];

  const handleNavClick = (view: AppView) => {
    if (view === 'PLAYING' && !hasActiveRound) {
      onQuickPlay();
    } else {
      onNavigate(view);
    }
    setMobileOpen(false);
  };

  const handleSearchFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit(localSearch);
    setMobileOpen(false);
  };

  const renderSidebarContent = (isMobile: boolean) => {
    const isSlim = !isMobile && collapsed;

    return (
      <div className="flex flex-col h-full justify-between">
        <div className="space-y-5">
          {/* Top Brand & Collapse Toggle */}
          <div
            className={`flex items-center ${
              isSlim ? 'justify-center' : 'justify-between'
            } px-1`}
          >
            {!isSlim && (
              <button
                type="button"
                onClick={() => handleNavClick('WORLDS')}
                className="font-display text-xl font-extrabold tracking-tight text-slate-900 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 rounded-md"
              >
                LetraCraft
              </button>
            )}

            {isMobile ? (
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="Cerrar menú"
                className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setCollapsed((prev) => !prev)}
                aria-label={collapsed ? 'Expandir barra lateral' : 'Contraer barra lateral'}
                className="p-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
              >
                {collapsed ? (
                  <PanelLeftOpen className="w-4 h-4" />
                ) : (
                  <PanelLeftClose className="w-4 h-4" />
                )}
              </button>
            )}
          </div>

          {/* Search box */}
          {!isSlim && (
            <form onSubmit={handleSearchFormSubmit} className="relative">
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={localSearch}
                onChange={(e) => {
                  setLocalSearch(e.target.value);
                  onSearchSubmit(e.target.value);
                }}
                placeholder="Buscar palabra..."
                aria-label="Buscar palabra en el vocabulario"
                className="w-full pl-9 pr-3 py-2 min-h-[40px] text-sm bg-slate-100/80 border border-slate-200/70 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-indigo-600"
              />
            </form>
          )}

          {/* Primary Navigation */}
          <div className="space-y-1">
            {!isSlim && (
              <div className="px-2 pb-1 text-xs font-medium text-slate-400">
                Navegación
              </div>
            )}

            {primaryItems.map((item) => {
              const Icon = item.icon;
              const isCurrent =
                activeView === item.view ||
                (item.view === 'PLAYING' && activeView === 'ROUND_SUMMARY');

              return (
                <button
                  key={item.view}
                  type="button"
                  onClick={() => handleNavClick(item.view)}
                  title={isSlim ? item.label : undefined}
                  className={`w-full flex items-center ${
                    isSlim ? 'justify-center px-2' : 'justify-between px-2.5'
                  } py-2 min-h-[42px] rounded-xl text-sm font-medium transition-colors ${
                    isCurrent
                      ? 'bg-slate-100 text-slate-900 font-semibold'
                      : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className={`w-7 h-7 rounded-full ${item.iconBg} text-white flex items-center justify-center shrink-0`}
                    >
                      <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                    </span>
                    {!isSlim && (
                      <span className="truncate whitespace-nowrap">
                        {item.label}
                      </span>
                    )}
                  </div>

                  {!isSlim && typeof item.count === 'number' && item.count > 0 && (
                    <span className="font-mono text-xs text-slate-400 tabular-nums">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Worlds Quick Progress List */}
          {!isSlim && (
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="px-2 flex items-center justify-between text-xs font-medium text-slate-400">
                <span>Mundos (1000)</span>
              </div>

              <div className="space-y-1.5">
                {WORLDS.map((world, idx) => {
                  const worldItems = ALL_CHALLENGES.filter(
                    (c) => c.worldId === world.id
                  );
                  const done = worldItems.filter((c) =>
                    completedSet.has(c.id)
                  ).length;
                  const pct = Math.round((done / worldItems.length) * 100);

                  return (
                    <button
                      key={world.id}
                      type="button"
                      onClick={() => {
                        onStartWorld(world.id);
                        setMobileOpen(false);
                      }}
                      className="w-full px-2.5 py-2 rounded-xl hover:bg-slate-50 transition-colors text-left space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <span className="font-medium text-slate-700 truncate">
                          Mundo {idx + 1}
                        </span>
                        <span className="font-mono text-slate-400 tabular-nums shrink-0">
                          {pct}%
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Utility Row */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={onToggleSound}
            aria-label={progress.soundEnabled ? 'Silenciar audio' : 'Activar audio'}
            className="inline-flex items-center gap-2 px-2.5 py-2 min-h-[40px] text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
          >
            {progress.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-indigo-600" aria-hidden="true" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" aria-hidden="true" />
            )}
            {!isSlim && (
              <span>{progress.soundEnabled ? 'Audio' : 'Silencio'}</span>
            )}
          </button>

          {!isSlim && (
            <button
              type="button"
              onClick={() => {
                onQuickPlay();
                setMobileOpen(false);
              }}
              className="px-3 py-2 min-h-[38px] text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              {hasActiveRound ? 'Continuar' : 'Jugar'}
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Desktop Floating Rounded Sidebar */}
      <aside
        aria-label="Menú lateral"
        className={`hidden lg:flex flex-col shrink-0 bg-white/95 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-4 transition-all duration-200 sticky top-5 h-[calc(100vh-2.5rem)] ${
          collapsed ? 'w-[76px]' : 'w-[264px]'
        }`}
      >
        {renderSidebarContent(false)}
      </aside>

      {/* Mobile Compact Header Trigger */}
      <div className="lg:hidden flex items-center justify-between gap-3 mb-4">
        <button
          type="button"
          onClick={() => setMobileOpen(true)}
          aria-label="Abrir menú de navegación"
          className="inline-flex items-center gap-2.5 px-3.5 py-2 min-h-[44px] bg-white/95 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl text-sm font-display font-extrabold text-slate-900"
        >
          <Menu className="w-4 h-4 text-slate-700" aria-hidden="true" />
          <span>LetraCraft</span>
        </button>

        <button
          type="button"
          onClick={onQuickPlay}
          className="px-4 py-2 min-h-[44px] text-xs font-semibold text-white bg-indigo-600 rounded-2xl shadow-sm hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0"
        >
          {hasActiveRound ? 'Continuar' : 'Jugar Ahora'}
        </button>
      </div>

      {/* Mobile Floating Drawer Overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 flex p-3 bg-slate-900/20 backdrop-blur-xs"
          onClick={() => setMobileOpen(false)}
        >
          <div
            className="w-[272px] max-w-[85vw] h-full bg-white rounded-3xl shadow-xl p-4"
            onClick={(e) => e.stopPropagation()}
          >
            {renderSidebarContent(true)}
          </div>
        </div>
      )}
    </>
  );
}
