import { ArrowRight, CheckCircle2, RotateCcw, Trophy } from 'lucide-react';
import { RoundItemResult } from '../types/game';
import { speakEnglish } from '../utils/audio';
import { ProgressRing, SegmentedBar } from './Charts';

interface RoundSummaryViewProps {
  title: string;
  results: RoundItemResult[];
  xpEarned: number;
  reviewCount: number;
  onReplayRound: () => void;
  onPracticeMistakes: () => void;
  onBackToWorlds: () => void;
}

export function RoundSummaryView({
  title,
  results,
  xpEarned,
  reviewCount,
  onReplayRound,
  onPracticeMistakes,
  onBackToWorlds,
}: RoundSummaryViewProps) {
  const totalMistakes = results.reduce((sum, r) => sum + r.mistakes, 0);
  const cleanCount = results.filter(
    (r) => r.mistakes === 0 && !r.usedRevealHint
  ).length;
  const roundMistakes = results.filter(
    (r) => r.mistakes > 0 || r.usedRevealHint
  );
  const cleanPercent =
    results.length > 0 ? Math.round((cleanCount / results.length) * 100) : 100;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <section className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-10 space-y-7">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700">
              <Trophy className="w-5 h-5" aria-hidden="true" />
              <span>Ronda completada</span>
            </div>

            <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900">
              {title}
            </h1>

            <p className="text-slate-600 text-sm sm:text-base max-w-lg">
              Completaste {results.length}{' '}
              {results.length === 1 ? 'reto' : 'retos'} letra por letra.
              {roundMistakes.length > 0
                ? ' Los términos con errores quedaron guardados en tu cola de repaso.'
                : ' ¡Excelente precisión sin errores en esta ronda!'}
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-50/90 border border-slate-200/70 rounded-2xl p-4 self-start sm:self-auto shrink-0">
            <ProgressRing
              percent={cleanPercent}
              size={72}
              strokeWidth={7}
              colorClass={
                cleanPercent >= 80 ? 'text-emerald-600' : 'text-indigo-600'
              }
            />
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-slate-500">
                Precisión de ronda
              </div>
              <div className="font-mono text-lg font-bold text-indigo-700 tabular-nums">
                +{xpEarned} XP
              </div>
              <div className="font-mono text-xs text-slate-500 tabular-nums">
                {totalMistakes} {totalMistakes === 1 ? 'error' : 'errores'}
              </div>
            </div>
          </div>
        </div>

        {/* Visual Breakdown Bar */}
        <div className="bg-slate-50/90 border border-slate-200/70 rounded-2xl p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between text-xs font-medium text-slate-600">
            <span>Balance de esta ronda</span>
            <span className="font-mono tabular-nums">
              {cleanCount}/{results.length} perfectos
            </span>
          </div>
          <SegmentedBar
            total={Math.max(1, results.length)}
            heightClass="h-3"
            segments={[
              {
                label: 'Sin errores',
                value: cleanCount,
                colorClass: 'bg-emerald-500',
              },
              {
                label: 'Con errores o pista',
                value: roundMistakes.length,
                colorClass: 'bg-amber-500',
              },
            ]}
          />
        </div>

        {/* Itemized Results */}
        <div className="space-y-3">
          <h2 className="font-display text-lg font-bold text-slate-900">
            Detalle de la ronda
          </h2>
          <ul className="divide-y divide-slate-100 border border-slate-200/80 rounded-2xl overflow-hidden bg-white">
            {results.map((item) => {
              const perfect = item.mistakes === 0 && !item.usedRevealHint;
              return (
                <li
                  key={item.challengeId}
                  className="p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 hover:bg-slate-50/60 transition-colors"
                >
                  <div>
                    <button
                      type="button"
                      onClick={() => speakEnglish(item.english, true)}
                      className="font-display font-bold text-slate-900 hover:text-indigo-700 transition-colors text-left"
                    >
                      {item.english}
                    </button>
                    <div className="text-sm text-slate-600">{item.spanish}</div>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-semibold">
                    {perfect ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-700">
                        <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                        <span>Sin errores</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-amber-700 font-mono tabular-nums">
                        <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>
                          {item.mistakes}{' '}
                          {item.mistakes === 1 ? 'error' : 'errores'}
                          {item.usedRevealHint ? ' · pista usada' : ''}
                        </span>
                      </span>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-3 pt-1">
          {reviewCount > 0 && (
            <button
              type="button"
              onClick={onPracticeMistakes}
              className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-amber-600 text-white text-sm font-semibold rounded-xl hover:bg-amber-700 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600 focus-visible:ring-offset-2"
            >
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
              <span className="tabular-nums">
                Repasar errores ({reviewCount})
              </span>
            </button>
          )}

          <button
            type="button"
            onClick={onReplayRound}
            className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
          >
            <span>Volver a jugar</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onBackToWorlds}
            className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-slate-100 text-slate-800 text-sm font-semibold rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
          >
            <span>Explorar mundos</span>
          </button>
        </div>
      </section>
    </div>
  );
}
