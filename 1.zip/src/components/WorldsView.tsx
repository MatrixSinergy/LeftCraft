import { ArrowRight, Layers, RotateCcw } from 'lucide-react';
import { ALL_CHALLENGES, CHALLENGES, WORLDS } from '../data/curriculum';
import { ContentFilter, PlayerProgress, WorldInfo } from '../types/game';
import { MiniBlockBars, ProgressRing, SegmentedBar } from './Charts';

interface WorldsViewProps {
  progress: PlayerProgress;
  filter: ContentFilter;
  onChangeFilter: (filter: ContentFilter) => void;
  onStartWorld: (worldId: string) => void;
  onStartQuickMix: () => void;
  onOpenVocab1000: () => void;
  onOpenReview: () => void;
}

const ACCENT_STYLES: Record<
  WorldInfo['accentColor'],
  {
    headerBg: string;
    ringColor: string;
    barColor: string;
    segDoneColor: string;
    button: string;
  }
> = {
  indigo: {
    headerBg:
      'bg-gradient-to-br from-indigo-100/75 via-sky-50/75 to-slate-100/75',
    ringColor: 'text-indigo-600',
    barColor: 'bg-indigo-500',
    segDoneColor: 'bg-indigo-600',
    button: 'bg-indigo-600 hover:bg-indigo-700 text-white',
  },
  emerald: {
    headerBg:
      'bg-gradient-to-br from-emerald-100/75 via-teal-50/75 to-slate-100/75',
    ringColor: 'text-emerald-600',
    barColor: 'bg-emerald-500',
    segDoneColor: 'bg-emerald-600',
    button: 'bg-emerald-600 hover:bg-emerald-700 text-white',
  },
  amber: {
    headerBg:
      'bg-gradient-to-br from-amber-100/75 via-orange-50/75 to-slate-100/75',
    ringColor: 'text-amber-600',
    barColor: 'bg-amber-500',
    segDoneColor: 'bg-amber-600',
    button: 'bg-amber-600 hover:bg-amber-700 text-white',
  },
  rose: {
    headerBg:
      'bg-gradient-to-br from-rose-100/75 via-pink-50/75 to-slate-100/75',
    ringColor: 'text-rose-600',
    barColor: 'bg-rose-500',
    segDoneColor: 'bg-rose-600',
    button: 'bg-rose-600 hover:bg-rose-700 text-white',
  },
};

export function WorldsView({
  progress,
  filter,
  onChangeFilter,
  onStartWorld,
  onStartQuickMix,
  onOpenVocab1000,
  onOpenReview,
}: WorldsViewProps) {
  const completedSet = new Set(progress.completedChallengeIds);
  const reviewSet = new Set(progress.reviewQueueIds);

  const globalDone = completedSet.size;
  const globalReview = ALL_CHALLENGES.filter(
    (c) => reviewSet.has(c.id) && !completedSet.has(c.id)
  ).length;
  const globalPending = Math.max(
    0,
    ALL_CHALLENGES.length - globalDone - globalReview
  );
  const globalPercent = Math.round((globalDone / ALL_CHALLENGES.length) * 100);

  const totalAccuracy =
    progress.totalLettersTapped > 0
      ? Math.round(
          (progress.correctLettersFirstTry / progress.totalLettersTapped) * 100
        )
      : 100;

  return (
    <div className="space-y-8">
      {/* Hero Overview Card */}
      <section className="bg-white/90 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-8 flex flex-col xl:flex-row xl:items-center xl:justify-between gap-8">
        <div className="max-w-xl space-y-4">
          <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
            <span>Inglés desde español</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              {ALL_CHALLENGES.length} palabras y expresiones
            </span>
            <span aria-hidden="true">·</span>
            <span>Selección letra por letra</span>
          </div>

          <h1
            className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 leading-[1.15]"
            style={{ textWrap: 'balance' }}
          >
            Aprende cada palabra escribiéndola letra por letra
          </h1>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Visualiza la pareja Español — Inglés, selecciona los bloques de
            letras en orden y sigue tu avance con gráficos en tiempo real.
          </p>

          <div className="pt-1 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onStartQuickMix}
              className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] bg-indigo-600 text-white font-semibold text-sm rounded-xl hover:bg-indigo-700 active:translate-y-px transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
            >
              <span>Práctica rápida</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={onOpenVocab1000}
              className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] bg-slate-900 text-white font-semibold text-sm rounded-xl hover:bg-slate-800 transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900 focus-visible:ring-offset-2"
            >
              <Layers className="w-4 h-4" aria-hidden="true" />
              <span>Explorar 1000</span>
            </button>

            {progress.reviewQueueIds.length > 0 && (
              <button
                type="button"
                onClick={onOpenReview}
                className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] bg-amber-50 border border-amber-200 text-amber-900 font-semibold text-sm rounded-xl hover:bg-amber-100 transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600"
              >
                <RotateCcw className="w-4 h-4" aria-hidden="true" />
                <span className="tabular-nums">
                  Repasar ({progress.reviewQueueIds.length})
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Visual Progress Charts Panel */}
        <div className="xl:min-w-[340px] bg-slate-50/90 border border-slate-200/70 rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-around gap-4">
            <div className="flex items-center gap-3">
              <ProgressRing
                percent={globalPercent}
                size={68}
                strokeWidth={7}
                colorClass="text-indigo-600"
              />
              <div>
                <div className="text-xs font-medium text-slate-500">
                  Dominio global
                </div>
                <div className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                  {globalDone}/{ALL_CHALLENGES.length}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <ProgressRing
                percent={totalAccuracy}
                size={68}
                strokeWidth={7}
                colorClass="text-emerald-600"
              />
              <div>
                <div className="text-xs font-medium text-slate-500">
                  Precisión
                </div>
                <div className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                  Racha {progress.currentStreak}
                </div>
              </div>
            </div>
          </div>

          <SegmentedBar
            total={ALL_CHALLENGES.length}
            heightClass="h-2.5"
            segments={[
              {
                label: 'Dominadas',
                value: globalDone,
                colorClass: 'bg-emerald-500',
              },
              {
                label: 'En repaso',
                value: globalReview,
                colorClass: 'bg-amber-500',
              },
              {
                label: 'Pendientes',
                value: globalPending,
                colorClass: 'bg-slate-300',
              },
            ]}
          />
        </div>
      </section>

      {/* Worlds Section Header & Segmented Filter */}
      <section className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-slate-900">
              Mundos temáticos (1,000 palabras)
            </h2>
            <p className="text-sm text-slate-600 mt-0.5">
              Avance visual por bloques dentro de cada mundo.
            </p>
          </div>

          {/* Interactive filter control */}
          <div
            role="group"
            aria-label="Filtrar tipo de contenido"
            className="inline-flex items-center gap-1 p-1 bg-white/80 backdrop-blur-sm border border-white/80 rounded-xl shadow-xs self-start sm:self-auto"
          >
            {(
              [
                { value: 'all', label: 'Todo' },
                { value: 'word', label: 'Solo Palabras' },
                { value: 'phrase', label: 'Solo Frases' },
              ] as const
            ).map((tab) => {
              const active = filter === tab.value;
              return (
                <button
                  key={tab.value}
                  type="button"
                  onClick={() => onChangeFilter(tab.value)}
                  className={`px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
                    active
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* 2x2 Worlds Grid with Diffused Graphic Headers & Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {WORLDS.map((world) => {
            const worldChallenges = CHALLENGES.filter(
              (c) =>
                c.worldId === world.id &&
                (filter === 'all' || c.type === filter)
            );
            const allWorldChallenges = CHALLENGES.filter(
              (c) => c.worldId === world.id
            );
            const doneCount = allWorldChallenges.filter((c) =>
              completedSet.has(c.id)
            ).length;
            const reviewCount = allWorldChallenges.filter(
              (c) => reviewSet.has(c.id) && !completedSet.has(c.id)
            ).length;
            const pendingCount = Math.max(
              0,
              allWorldChallenges.length - doneCount - reviewCount
            );
            const percent = Math.round(
              (doneCount / allWorldChallenges.length) * 100
            );

            // Compute 10 mini-chunk completion bars (25 words per bar)
            const chunkSize = 25;
            const miniBarValues = Array.from({ length: 10 }, (_, idx) => {
              const slice = allWorldChallenges.slice(
                idx * chunkSize,
                (idx + 1) * chunkSize
              );
              if (slice.length === 0) return 0;
              const sliceDone = slice.filter((c) =>
                completedSet.has(c.id)
              ).length;
              return Math.round((sliceDone / slice.length) * 100);
            });

            const styles = ACCENT_STYLES[world.accentColor];
            const isEmptyForFilter = worldChallenges.length === 0;

            return (
              <article
                key={world.id}
                className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl overflow-hidden flex flex-col justify-between"
              >
                <div>
                  {/* Diffused Flat Color Graphic Header (No Background Image) */}
                  <div
                    className={`${styles.headerBg} p-6 border-b border-slate-200/50 space-y-4`}
                  >
                    <div className="flex items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="text-xs font-medium text-slate-600">
                          {world.levelRange} ·{' '}
                          <span className="font-mono tabular-nums">
                            {worldChallenges.length} en filtro
                          </span>
                        </div>
                        <h3 className="font-display text-xl font-bold text-slate-900">
                          {world.title}
                        </h3>
                      </div>

                      <ProgressRing
                        percent={percent}
                        size={64}
                        strokeWidth={6}
                        colorClass={styles.ringColor}
                        trackClass="text-white/80"
                      />
                    </div>

                    {/* 10-column Mini Bar Chart of Sub-Blocks */}
                    <div className="space-y-1.5">
                      <div className="text-[11px] font-medium text-slate-500">
                        Mapa de progreso (10 tramos de 25 palabras)
                      </div>
                      <MiniBlockBars
                        values={miniBarValues}
                        barColorClass={styles.barColor}
                      />
                    </div>
                  </div>

                  <div className="p-6 space-y-4">
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {world.subtitle}
                    </p>

                    <SegmentedBar
                      total={allWorldChallenges.length}
                      heightClass="h-2.5"
                      segments={[
                        {
                          label: 'Dominadas',
                          value: doneCount,
                          colorClass: styles.segDoneColor,
                        },
                        {
                          label: 'Repaso',
                          value: reviewCount,
                          colorClass: 'bg-amber-500',
                        },
                        {
                          label: 'Pendientes',
                          value: pendingCount,
                          colorClass: 'bg-slate-200',
                        },
                      ]}
                    />
                  </div>
                </div>

                <div className="px-6 pb-6 pt-1">
                  <button
                    type="button"
                    disabled={isEmptyForFilter}
                    onClick={() => onStartWorld(world.id)}
                    className={`w-full py-2.5 px-4 min-h-[44px] rounded-xl text-sm font-semibold transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2 ${
                      isEmptyForFilter
                        ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                        : styles.button
                    }`}
                  >
                    {isEmptyForFilter
                      ? 'Sin retos en este filtro'
                      : 'Practicar siguientes 20'}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
}
