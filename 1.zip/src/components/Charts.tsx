interface ProgressRingProps {
  percent: number;
  size?: number;
  strokeWidth?: number;
  colorClass?: string;
  trackClass?: string;
  label?: string;
}

export function ProgressRing({
  percent,
  size = 72,
  strokeWidth = 7,
  colorClass = 'text-indigo-600',
  trackClass = 'text-slate-200/80',
  label,
}: ProgressRingProps) {
  const clamped = Math.max(0, Math.min(100, percent));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clamped / 100) * circumference;

  return (
    <div
      className="relative inline-flex items-center justify-center shrink-0"
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="-rotate-90"
        aria-hidden="true"
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className={trackClass}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className={`${colorClass} transition-all duration-300`}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono text-xs sm:text-sm font-bold text-slate-900 tabular-nums">
          {label ?? `${clamped}%`}
        </span>
      </div>
    </div>
  );
}

export interface BarSegment {
  label: string;
  value: number;
  colorClass: string;
}

interface SegmentedBarProps {
  total: number;
  segments: BarSegment[];
  heightClass?: string;
  showLegend?: boolean;
}

export function SegmentedBar({
  total,
  segments,
  heightClass = 'h-3',
  showLegend = true,
}: SegmentedBarProps) {
  const safeTotal = Math.max(1, total);

  return (
    <div className="space-y-2.5 w-full">
      <div
        className={`w-full ${heightClass} bg-slate-200/80 rounded-full overflow-hidden flex`}
      >
        {segments.map((seg) => {
          const pct = (seg.value / safeTotal) * 100;
          if (pct <= 0) return null;
          return (
            <div
              key={seg.label}
              title={`${seg.label}: ${seg.value}`}
              className={`${seg.colorClass} h-full transition-all duration-300`}
              style={{ width: `${pct}%` }}
            />
          );
        })}
      </div>

      {showLegend && (
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
          {segments.map((seg) => (
            <div key={seg.label} className="inline-flex items-center gap-1.5">
              <span
                aria-hidden="true"
                className={`w-2.5 h-2.5 rounded-sm ${seg.colorClass}`}
              />
              <span>{seg.label}</span>
              <span className="font-mono font-semibold text-slate-800 tabular-nums">
                {seg.value}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

interface MiniBlockBarsProps {
  values: number[]; // percentages 0..100
  barColorClass?: string;
}

export function MiniBlockBars({
  values,
  barColorClass = 'bg-indigo-500',
}: MiniBlockBarsProps) {
  return (
    <div
      className="flex items-end gap-1.5 h-12 w-full"
      aria-label="Gráfico de avance por bloques"
    >
      {values.map((val, idx) => {
        const heightPct = Math.max(14, Math.min(100, val));
        const hasProgress = val > 0;
        return (
          <div
            key={idx}
            title={`Sub-bloque ${idx + 1}: ${val}%`}
            className="flex-1 h-full flex items-end bg-white/60 rounded-md overflow-hidden p-0.5"
          >
            <div
              className={`w-full rounded-sm transition-all duration-300 ${
                hasProgress ? barColorClass : 'bg-slate-300/60'
              }`}
              style={{ height: `${heightPct}%` }}
            />
          </div>
        );
      })}
    </div>
  );
}

interface RoundStepBarProps {
  total: number;
  currentIndex: number;
  completedStatuses: ('clean' | 'assisted')[];
  currentCompleted: boolean;
  currentAssisted: boolean;
}

export function RoundStepBar({
  total,
  currentIndex,
  completedStatuses,
  currentCompleted,
  currentAssisted,
}: RoundStepBarProps) {
  return (
    <div
      className="flex items-center gap-1.5 w-full"
      aria-label={`Progreso de ronda: reto ${currentIndex + 1} de ${total}`}
    >
      {Array.from({ length: total }, (_, idx) => {
        let color = 'bg-slate-200/90';
        if (idx < completedStatuses.length) {
          color =
            completedStatuses[idx] === 'clean'
              ? 'bg-emerald-500'
              : 'bg-amber-500';
        } else if (idx === currentIndex) {
          if (currentCompleted) {
            color = currentAssisted ? 'bg-amber-500' : 'bg-emerald-500';
          } else {
            color = 'bg-indigo-600';
          }
        }

        return (
          <div
            key={idx}
            className={`h-2.5 flex-1 rounded-full transition-all duration-200 ${color}`}
          />
        );
      })}
    </div>
  );
}
