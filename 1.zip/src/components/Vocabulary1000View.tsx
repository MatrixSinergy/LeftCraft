import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Search,
  Volume2,
} from 'lucide-react';
import {
  INTERMEDIATE_1000_CHALLENGES,
  INTERMEDIATE_BLOCKS,
} from '../data/intermediate1000';
import { ChallengeItem, PlayerProgress } from '../types/game';
import { speakEnglish } from '../utils/audio';
import { ProgressRing, SegmentedBar } from './Charts';

interface Vocabulary1000ViewProps {
  progress: PlayerProgress;
  externalSearchQuery?: string;
  onStartRound: (title: string, items: ChallengeItem[]) => void;
}

type LibraryMode = 'blocks' | 'search';
type LibraryFilter = 'all' | 'word' | 'phrase' | 'pending' | 'completed';

const ITEMS_PER_PAGE = 40;

export function Vocabulary1000View({
  progress,
  externalSearchQuery = '',
  onStartRound,
}: Vocabulary1000ViewProps) {
  const [mode, setMode] = useState<LibraryMode>(
    externalSearchQuery.trim() ? 'search' : 'blocks'
  );
  const [query, setQuery] = useState(externalSearchQuery);
  const [listFilter, setListFilter] = useState<LibraryFilter>('all');
  const [page, setPage] = useState(1);

  useEffect(() => {
    setQuery(externalSearchQuery);
    if (externalSearchQuery.trim()) {
      setMode('search');
      setPage(1);
    }
  }, [externalSearchQuery]);

  const completedSet = useMemo(
    () => new Set(progress.completedChallengeIds),
    [progress.completedChallengeIds]
  );

  const reviewSet = useMemo(
    () => new Set(progress.reviewQueueIds),
    [progress.reviewQueueIds]
  );

  const completed1000Count = useMemo(
    () =>
      INTERMEDIATE_1000_CHALLENGES.filter((c) => completedSet.has(c.id)).length,
    [completedSet]
  );

  const review1000Count = useMemo(
    () =>
      INTERMEDIATE_1000_CHALLENGES.filter(
        (c) => reviewSet.has(c.id) && !completedSet.has(c.id)
      ).length,
    [reviewSet, completedSet]
  );

  const pending1000Count = Math.max(
    0,
    INTERMEDIATE_1000_CHALLENGES.length - completed1000Count - review1000Count
  );

  const totalPercent = Math.round(
    (completed1000Count / INTERMEDIATE_1000_CHALLENGES.length) * 100
  );

  const handleStartNext20 = () => {
    const pending = INTERMEDIATE_1000_CHALLENGES.filter(
      (c) => !completedSet.has(c.id)
    );
    const batch = (
      pending.length > 0 ? pending : INTERMEDIATE_1000_CHALLENGES
    ).slice(0, 20);
    onStartRound('Intermedio · Siguientes 20', batch);
  };

  const filteredItems = useMemo(() => {
    const q = query.trim().toLowerCase();
    return INTERMEDIATE_1000_CHALLENGES.filter((item) => {
      if (listFilter === 'word' && item.type !== 'word') return false;
      if (listFilter === 'phrase' && item.type !== 'phrase') return false;
      if (listFilter === 'completed' && !completedSet.has(item.id)) return false;
      if (listFilter === 'pending' && completedSet.has(item.id)) return false;

      if (!q) return true;
      const en = (item.displayEnglish ?? item.english).toLowerCase();
      const es = item.spanish.toLowerCase();
      return en.includes(q) || es.includes(q);
    });
  }, [query, listFilter, completedSet]);

  const totalPages = Math.max(
    1,
    Math.ceil(filteredItems.length / ITEMS_PER_PAGE)
  );
  const safePage = Math.min(page, totalPages);
  const pageItems = filteredItems.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  );

  return (
    <div className="space-y-6">
      {/* Header & Visual Mastery Map */}
      <section className="bg-white/90 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
              <span>Nivel Intermedio</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                1000 palabras y expresiones
              </span>
              <span aria-hidden="true">·</span>
              <span>50 bloques de 20</span>
            </div>

            <h1
              className="font-display text-3xl font-extrabold text-slate-900 tracking-tight"
              style={{ textWrap: 'balance' }}
            >
              Vocabulario Intermedio (1,000 palabras)
            </h1>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Explora los 50 bloques progresivos en el mapa visual o busca
              cualquier término para practicarlo letra por letra.
            </p>

            <div className="pt-1 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleStartNext20}
                className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
              >
                <span>Practicar siguientes 20</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>

              <div
                role="group"
                aria-label="Modo de visualización"
                className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-xl"
              >
                <button
                  type="button"
                  onClick={() => setMode('blocks')}
                  className={`px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    mode === 'blocks'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  50 Bloques
                </button>
                <button
                  type="button"
                  onClick={() => setMode('search')}
                  className={`px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    mode === 'search'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Buscador (1000)
                </button>
              </div>
            </div>
          </div>

          <div className="xl:min-w-[320px] bg-slate-50/90 border border-slate-200/70 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-4">
              <ProgressRing
                percent={totalPercent}
                size={72}
                strokeWidth={7}
                colorClass="text-indigo-600"
              />
              <div>
                <div className="text-xs font-medium text-slate-500">
                  Avance total
                </div>
                <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
                  {completed1000Count}/1000
                </div>
              </div>
            </div>

            <SegmentedBar
              total={INTERMEDIATE_1000_CHALLENGES.length}
              heightClass="h-2.5"
              segments={[
                {
                  label: 'Dominadas',
                  value: completed1000Count,
                  colorClass: 'bg-emerald-500',
                },
                {
                  label: 'Repaso',
                  value: review1000Count,
                  colorClass: 'bg-amber-500',
                },
                {
                  label: 'Pendientes',
                  value: pending1000Count,
                  colorClass: 'bg-slate-300',
                },
              ]}
            />
          </div>
        </div>

        {/* 50-Block Visual Mastery Heatmap */}
        <div className="pt-4 border-t border-slate-200/70 space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
            <span className="font-medium">
              Mapa visual de los 50 bloques (toca cualquier cuadro para practicarlo)
            </span>
            <span className="font-mono tabular-nums">20 palabras por bloque</span>
          </div>

          <div className="grid grid-cols-10 sm:grid-cols-[repeat(25,minmax(0,1fr))] gap-1.5">
            {INTERMEDIATE_BLOCKS.map((block) => {
              const done = block.items.filter((i) =>
                completedSet.has(i.id)
              ).length;
              const pct = Math.round((done / block.items.length) * 100);

              let cellStyle =
                'bg-slate-100 text-slate-500 hover:bg-indigo-100 hover:text-indigo-800';
              if (pct === 100) {
                cellStyle = 'bg-emerald-500 text-white hover:bg-emerald-600';
              } else if (pct > 0) {
                cellStyle = 'bg-indigo-500 text-white hover:bg-indigo-600';
              }

              return (
                <button
                  key={block.blockNumber}
                  type="button"
                  title={`Bloque ${block.blockNumber} (#${block.startRank}–${block.endRank}): ${done}/20 (${pct}%)`}
                  onClick={() =>
                    onStartRound(
                      `Intermedio · Bloque ${block.blockNumber}`,
                      block.items
                    )
                  }
                  className={`h-7 rounded-md font-mono text-[10px] font-bold tabular-nums transition-colors ${cellStyle}`}
                >
                  {block.blockNumber}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {mode === 'blocks' ? (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold text-slate-900">
              Módulos progresivos (20 retos por bloque)
            </h2>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              50 bloques disponibles
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {INTERMEDIATE_BLOCKS.map((block) => {
              const done = block.items.filter((i) =>
                completedSet.has(i.id)
              ).length;
              const pct = Math.round((done / block.items.length) * 100);
              const preview = block.items
                .slice(0, 3)
                .map((i) => i.displayEnglish ?? i.english.toLowerCase())
                .join(', ');

              return (
                <article
                  key={block.blockNumber}
                  className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl p-5 flex flex-col justify-between gap-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1 min-w-0">
                      <div className="text-xs font-mono text-slate-500 tabular-nums">
                        #{block.startRank}–{block.endRank}
                      </div>
                      <h3 className="font-display text-lg font-bold text-slate-900">
                        Bloque {block.blockNumber}
                      </h3>
                      <p className="text-xs text-slate-600 truncate">
                        {preview}...
                      </p>
                    </div>

                    <ProgressRing
                      percent={pct}
                      size={52}
                      strokeWidth={5}
                      colorClass={
                        pct === 100 ? 'text-emerald-600' : 'text-indigo-600'
                      }
                      label={`${done}/20`}
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          pct === 100 ? 'bg-emerald-500' : 'bg-indigo-600'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        onStartRound(
                          `Intermedio · Bloque ${block.blockNumber}`,
                          block.items
                        )
                      }
                      className={`w-full py-2 px-4 min-h-[40px] rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
                        pct === 100
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                          : 'bg-slate-900 text-white hover:bg-slate-800'
                      }`}
                    >
                      {pct === 100 ? 'Repasar bloque' : 'Practicar bloque'}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      ) : (
        <section className="space-y-5">
          {/* Search & Filter Controls */}
          <div className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2"
                aria-hidden="true"
              />
              <input
                type="search"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setPage(1);
                }}
                placeholder="Buscar palabra en inglés o español..."
                aria-label="Buscar en las 1000 palabras"
                className="w-full pl-10 pr-4 py-2.5 min-h-[44px] text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {(
                [
                  { value: 'all', label: 'Todas' },
                  { value: 'word', label: 'Palabras' },
                  { value: 'phrase', label: 'Frases' },
                  { value: 'pending', label: 'Pendientes' },
                  { value: 'completed', label: 'Dominadas' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.value}
                  type="button"
                  onClick={() => {
                    setListFilter(tab.value);
                    setPage(1);
                  }}
                  className={`px-3 py-2 min-h-[40px] text-xs font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 ${
                    listFilter === tab.value
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Results Summary Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="text-sm font-medium text-slate-700 font-mono tabular-nums">
              {filteredItems.length}{' '}
              {filteredItems.length === 1 ? 'resultado' : 'resultados'}
            </span>

            {filteredItems.length > 0 && (
              <button
                type="button"
                onClick={() =>
                  onStartRound(
                    `Selección Intermedio (${Math.min(20, filteredItems.length)})`,
                    filteredItems.slice(0, 20)
                  )
                }
                className="inline-flex items-center gap-2 px-4 py-2 min-h-[40px] bg-indigo-600 text-white text-xs font-semibold rounded-xl hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0"
              >
                <span>
                  Practicar primeros {Math.min(20, filteredItems.length)}
                </span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            )}
          </div>

          {/* Paginated Table/List */}
          {pageItems.length === 0 ? (
            <div className="bg-white/92 backdrop-blur-md border border-white/80 rounded-2xl p-10 text-center text-slate-600 text-sm">
              No se encontraron palabras que coincidan con tu búsqueda.
            </div>
          ) : (
            <div className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl divide-y divide-slate-100 overflow-hidden">
              {pageItems.map((item) => {
                const rank = item.id.replace('int-', '');
                const isDone = completedSet.has(item.id);
                const displayEn = item.displayEnglish ?? item.english;

                return (
                  <div
                    key={item.id}
                    className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 hover:bg-slate-50/70 transition-colors"
                  >
                    <div className="flex items-start sm:items-center gap-4 min-w-0">
                      <span className="font-mono text-xs font-semibold text-slate-400 tabular-nums w-9 shrink-0 pt-1 sm:pt-0">
                        #{rank}
                      </span>

                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-display font-bold text-base sm:text-lg text-slate-900">
                            {displayEn}
                          </span>
                          {isDone && (
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                              <CheckCircle2
                                className="w-3.5 h-3.5"
                                aria-hidden="true"
                              />
                              <span>Dominada</span>
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-slate-600">
                          {item.spanish} ·{' '}
                          <span className="text-slate-400">
                            {item.type === 'word' ? 'Palabra' : 'Frase'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 pl-13 sm:pl-0">
                      <button
                        type="button"
                        onClick={() => speakEnglish(displayEn, true)}
                        className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0"
                      >
                        <Volume2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Escuchar</span>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          onStartRound(`Práctica · ${displayEn}`, [item])
                        }
                        className="px-3.5 py-2 min-h-[40px] text-xs font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0"
                      >
                        Practicar
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] text-xs font-semibold bg-white/90 border border-white/80 rounded-xl text-slate-700 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed whitespace-nowrap shrink-0"
              >
                <ChevronLeft className="w-4 h-4" aria-hidden="true" />
                <span>Anterior</span>
              </button>

              <span className="font-mono text-xs font-semibold text-slate-700 tabular-nums">
                Página {safePage} de {totalPages}
              </span>

              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] text-xs font-semibold bg-white/90 border border-white/80 rounded-xl text-slate-700 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed whitespace-nowrap shrink-0"
              >
                <span>Siguiente</span>
                <ChevronRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
