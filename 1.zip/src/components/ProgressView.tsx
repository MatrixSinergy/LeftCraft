import { useState } from 'react';
import { Download, FileArchive, Flame, Sparkles, Trash2 } from 'lucide-react';
import { ALL_CHALLENGES, CHALLENGES, WORLDS } from '../data/curriculum';
import { PlayerProgress } from '../types/game';
import { ProgressRing, SegmentedBar } from './Charts';

interface ProgressViewProps {
  progress: PlayerProgress;
  onStartWorld: (worldId: string) => void;
  onOpenVocab1000: () => void;
  onResetProgress: () => void;
}

const WORLD_BAR_COLORS = [
  'bg-indigo-500',
  'bg-emerald-500',
  'bg-amber-500',
  'bg-rose-500',
];

export function ProgressView({
  progress,
  onStartWorld,
  onOpenVocab1000,
  onResetProgress,
}: ProgressViewProps) {
  const [confirmReset, setConfirmReset] = useState(false);

  const completedSet = new Set(progress.completedChallengeIds);
  const reviewSet = new Set(progress.reviewQueueIds);

  const totalCount = ALL_CHALLENGES.length;
  const doneCount = completedSet.size;
  const reviewCount = ALL_CHALLENGES.filter(
    (c) => reviewSet.has(c.id) && !completedSet.has(c.id)
  ).length;
  const pendingCount = Math.max(0, totalCount - doneCount - reviewCount);
  const globalPercent = Math.round((doneCount / totalCount) * 100);

  const accuracy =
    progress.totalLettersTapped > 0
      ? Math.round(
          (progress.correctLettersFirstTry / progress.totalLettersTapped) * 100
        )
      : 100;

  // Words vs Phrases stats
  const allWords = ALL_CHALLENGES.filter((c) => c.type === 'word');
  const allPhrases = ALL_CHALLENGES.filter((c) => c.type === 'phrase');
  const wordsDone = allWords.filter((c) => completedSet.has(c.id)).length;
  const wordsReview = allWords.filter(
    (c) => reviewSet.has(c.id) && !completedSet.has(c.id)
  ).length;
  const wordsPending = Math.max(0, allWords.length - wordsDone - wordsReview);

  const phrasesDone = allPhrases.filter((c) => completedSet.has(c.id)).length;
  const phrasesReview = allPhrases.filter(
    (c) => reviewSet.has(c.id) && !completedSet.has(c.id)
  ).length;
  const phrasesPending = Math.max(
    0,
    allPhrases.length - phrasesDone - phrasesReview
  );

  // Streak & XP visual benchmarks
  const nextXpMilestone = Math.max(250, Math.ceil((progress.xp + 1) / 250) * 250);
  const xpMilestonePct = Math.min(
    100,
    Math.round(((progress.xp % 250) / 250) * 100) || (progress.xp > 0 ? 100 : 0)
  );
  const streakRatioPct =
    progress.bestStreak > 0
      ? Math.round((progress.currentStreak / progress.bestStreak) * 100)
      : 0;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header + Primary Visual Charts */}
      <section className="bg-white/90 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="space-y-2">
          <div className="text-xs font-medium text-slate-500">
            Panel visual de aprendizaje
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900">
            Tu progreso
          </h1>
          <p className="text-slate-600 text-sm sm:text-base">
            Seguimiento visual por palabra, letra correcta y avance en los 4
            mundos del vocabulario de 1,000 términos.
          </p>
        </div>

        {/* Rings + Linear Bar Benchmarks */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Dual Progress Rings */}
          <div className="bg-slate-50/90 border border-slate-200/70 rounded-2xl p-5 flex items-center justify-around gap-4">
            <div className="flex items-center gap-3.5">
              <ProgressRing
                percent={globalPercent}
                size={76}
                strokeWidth={7}
                colorClass="text-indigo-600"
              />
              <div>
                <div className="text-xs font-medium text-slate-500">
                  Dominio total
                </div>
                <div className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                  {doneCount}/{totalCount}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3.5">
              <ProgressRing
                percent={accuracy}
                size={76}
                strokeWidth={7}
                colorClass="text-emerald-600"
              />
              <div>
                <div className="text-xs font-medium text-slate-500">
                  Precisión letras
                </div>
                <div className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                  {progress.correctLettersFirstTry}/
                  {progress.totalLettersTapped}
                </div>
              </div>
            </div>
          </div>

          {/* XP & Streak Visual Progress Bars */}
          <div className="bg-slate-50/90 border border-slate-200/70 rounded-2xl p-5 space-y-4">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="inline-flex items-center gap-1.5 font-semibold text-slate-700">
                  <Sparkles
                    className="w-3.5 h-3.5 text-indigo-600"
                    aria-hidden="true"
                  />
                  <span>Experiencia acumulada</span>
                </span>
                <span className="font-mono font-bold text-indigo-700 tabular-nums">
                  {progress.xp} / {nextXpMilestone} XP
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-200/80 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                  style={{ width: `${xpMilestonePct}%` }}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="inline-flex items-center gap-1.5 font-semibold text-slate-700">
                  <Flame
                    className="w-3.5 h-3.5 text-amber-600"
                    aria-hidden="true"
                  />
                  <span>Racha actual vs mejor racha</span>
                </span>
                <span className="font-mono font-bold text-amber-700 tabular-nums">
                  {progress.currentStreak} / {progress.bestStreak}
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-200/80 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full transition-all duration-300"
                  style={{ width: `${streakRatioPct}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Global Stacked Distribution Bar */}
        <div className="pt-2 space-y-2">
          <div className="flex items-center justify-between text-xs font-medium text-slate-600">
            <span>Distribución de las 1,000 palabras</span>
            <span className="font-mono tabular-nums">{globalPercent}%</span>
          </div>
          <SegmentedBar
            total={totalCount}
            heightClass="h-3"
            segments={[
              {
                label: 'Dominadas',
                value: doneCount,
                colorClass: 'bg-emerald-500',
              },
              {
                label: 'En repaso',
                value: reviewCount,
                colorClass: 'bg-amber-500',
              },
              {
                label: 'Pendientes',
                value: pendingCount,
                colorClass: 'bg-slate-300',
              },
            ]}
          />
        </div>
      </section>

      {/* Words vs Phrases Mastery Bars */}
      <section className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-xl font-bold text-slate-900">
            Palabras vs. frases y expresiones
          </h2>
          <span className="text-xs font-mono text-slate-500 tabular-nums">
            {allWords.length} palabras · {allPhrases.length} frases
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-50/90 border border-slate-200/70 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
              <span>Palabras individuales</span>
              <span className="font-mono tabular-nums">
                {wordsDone}/{allWords.length}
              </span>
            </div>
            <SegmentedBar
              total={Math.max(1, allWords.length)}
              heightClass="h-2.5"
              segments={[
                {
                  label: 'Dominadas',
                  value: wordsDone,
                  colorClass: 'bg-indigo-600',
                },
                {
                  label: 'Repaso',
                  value: wordsReview,
                  colorClass: 'bg-amber-500',
                },
                {
                  label: 'Pendientes',
                  value: wordsPending,
                  colorClass: 'bg-slate-300',
                },
              ]}
            />
          </div>

          <div className="bg-slate-50/90 border border-slate-200/70 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
              <span>Frases y expresiones</span>
              <span className="font-mono tabular-nums">
                {phrasesDone}/{allPhrases.length}
              </span>
            </div>
            <SegmentedBar
              total={Math.max(1, allPhrases.length)}
              heightClass="h-2.5"
              segments={[
                {
                  label: 'Dominadas',
                  value: phrasesDone,
                  colorClass: 'bg-emerald-500',
                },
                {
                  label: 'Repaso',
                  value: phrasesReview,
                  colorClass: 'bg-amber-500',
                },
                {
                  label: 'Pendientes',
                  value: phrasesPending,
                  colorClass: 'bg-slate-300',
                },
              ]}
            />
          </div>
        </div>
      </section>

      {/* Comparative 4-World Bar Chart & Detail */}
      <section className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-xl font-bold text-slate-900">
            Avance comparativo por mundo (1,000 palabras)
          </h2>
          <button
            type="button"
            onClick={onOpenVocab1000}
            className="px-3.5 py-2 min-h-[40px] text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-xl hover:bg-indigo-100 transition-colors whitespace-nowrap shrink-0"
          >
            Ver lista de 1000 palabras
          </button>
        </div>

        {/* Vertical Bar Chart for the 4 Worlds */}
        <div className="bg-slate-50/90 border border-slate-200/70 rounded-2xl p-5">
          <div className="grid grid-cols-4 gap-3 sm:gap-6 items-end h-36 pt-4">
            {WORLDS.map((world, idx) => {
              const worldItems = CHALLENGES.filter(
                (c) => c.worldId === world.id
              );
              const worldDone = worldItems.filter((c) =>
                completedSet.has(c.id)
              ).length;
              const pct = Math.round((worldDone / worldItems.length) * 100);
              const barHeight = Math.max(8, pct);

              return (
                <div
                  key={world.id}
                  className="flex flex-col items-center h-full justify-end gap-2"
                >
                  <span className="font-mono text-xs font-bold text-slate-700 tabular-nums">
                    {pct}%
                  </span>
                  <div className="w-full max-w-[64px] flex-1 bg-slate-200/70 rounded-xl p-1 flex items-end overflow-hidden">
                    <div
                      className={`w-full rounded-lg transition-all duration-300 ${
                        WORLD_BAR_COLORS[idx % WORLD_BAR_COLORS.length]
                      }`}
                      style={{ height: `${barHeight}%` }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 text-center">
                    Mundo {idx + 1}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Detailed World Rows */}
        <div className="divide-y divide-slate-100">
          {WORLDS.map((world, idx) => {
            const worldItems = CHALLENGES.filter((c) => c.worldId === world.id);
            const worldDone = worldItems.filter((c) =>
              completedSet.has(c.id)
            ).length;
            const worldReview = worldItems.filter(
              (c) => reviewSet.has(c.id) && !completedSet.has(c.id)
            ).length;
            const worldPending = Math.max(
              0,
              worldItems.length - worldDone - worldReview
            );
            const percent = Math.round((worldDone / worldItems.length) * 100);

            return (
              <div
                key={world.id}
                className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex items-center justify-between gap-4">
                    <span className="font-semibold text-slate-900">
                      {world.title}{' '}
                      <span className="text-xs font-normal text-slate-500">
                        · {world.levelRange}
                      </span>
                    </span>
                    <span className="font-mono text-xs font-semibold text-slate-600 tabular-nums">
                      {worldDone}/{worldItems.length} ({percent}%)
                    </span>
                  </div>

                  <SegmentedBar
                    total={worldItems.length}
                    heightClass="h-2"
                    showLegend={false}
                    segments={[
                      {
                        label: 'Dominadas',
                        value: worldDone,
                        colorClass:
                          WORLD_BAR_COLORS[idx % WORLD_BAR_COLORS.length],
                      },
                      {
                        label: 'Repaso',
                        value: worldReview,
                        colorClass: 'bg-amber-500',
                      },
                      {
                        label: 'Pendientes',
                        value: worldPending,
                        colorClass: 'bg-slate-200',
                      },
                    ]}
                  />
                </div>

                <button
                  type="button"
                  onClick={() => onStartWorld(world.id)}
                  className="px-4 py-2 min-h-[40px] text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
                >
                  Practicar
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Downloadable Static Web Package */}
      <section className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">
            Archivos para subir la web
          </h2>
          <p className="text-sm text-slate-600">
            Descarga la versión estática compilada lista para subir a cPanel,
            Hostinger, Netlify o GitHub Pages.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <a
            href="./letracraft-index.html"
            download="index.html"
            className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[40px] text-xs font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Descargar index.html</span>
          </a>

          <a
            href="./letracraft-web.zip"
            download="letracraft-web.zip"
            className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[40px] text-xs font-semibold text-slate-800 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <FileArchive className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Descargar .zip</span>
          </a>
        </div>
      </section>

      {/* Safe inline two-step reset */}
      <section className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">
            Reiniciar datos locales
          </h2>
          <p className="text-sm text-slate-600">
            Borra tu XP, racha y cola de repaso para empezar desde cero.
          </p>
        </div>

        {!confirmReset ? (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[40px] text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl hover:bg-rose-100 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Reiniciar progreso</span>
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onResetProgress();
                setConfirmReset(false);
              }}
              className="px-4 py-2 min-h-[40px] text-xs font-semibold text-white bg-rose-600 rounded-xl hover:bg-rose-700 transition-colors whitespace-nowrap shrink-0"
            >
              Confirmar borrado
            </button>
            <button
              type="button"
              onClick={() => setConfirmReset(false)}
              className="px-4 py-2 min-h-[40px] text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0"
            >
              Cancelar
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
