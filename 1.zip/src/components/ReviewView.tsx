import { CheckCircle2, RotateCcw, Volume2 } from 'lucide-react';
import { ALL_CHALLENGES } from '../data/curriculum';
import { speakEnglish } from '../utils/audio';
import { ProgressRing, SegmentedBar } from './Charts';

interface ReviewViewProps {
  reviewQueueIds: string[];
  onStartReviewSession: () => void;
  onExploreWorlds: () => void;
}

export function ReviewView({
  reviewQueueIds,
  onStartReviewSession,
  onExploreWorlds,
}: ReviewViewProps) {
  const reviewItems = ALL_CHALLENGES.filter((c) => reviewQueueIds.includes(c.id));
  const wordCount = reviewItems.filter((c) => c.type === 'word').length;
  const phraseCount = reviewItems.filter((c) => c.type === 'phrase').length;
  const cleanPercent = Math.round(
    ((ALL_CHALLENGES.length - reviewItems.length) / ALL_CHALLENGES.length) * 100
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <section className="bg-white/90 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="text-xs font-medium text-slate-500">
              Repaso inteligente ·{' '}
              <span className="font-mono tabular-nums">
                {reviewItems.length}{' '}
                {reviewItems.length === 1
                  ? 'término pendiente'
                  : 'términos pendientes'}
              </span>
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900">
              Cola de repaso
            </h1>
            <p className="text-slate-600 text-sm sm:text-base">
              Aquí aparecen automáticamente las palabras y frases donde tuviste
              errores de letra o revelaste ayuda. Complétalas sin errores para
              despejarlas.
            </p>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <div className="bg-slate-50/90 border border-slate-200/70 rounded-2xl p-3.5 flex items-center gap-3">
              <ProgressRing
                percent={cleanPercent}
                size={56}
                strokeWidth={6}
                colorClass={
                  reviewItems.length === 0
                    ? 'text-emerald-600'
                    : 'text-amber-500'
                }
              />
              <div>
                <div className="text-[11px] font-medium text-slate-500">
                  Sin errores
                </div>
                <div className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                  {ALL_CHALLENGES.length - reviewItems.length}/
                  {ALL_CHALLENGES.length}
                </div>
              </div>
            </div>

            {reviewItems.length > 0 && (
              <button
                type="button"
                onClick={onStartReviewSession}
                className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
              >
                <RotateCcw className="w-4 h-4" aria-hidden="true" />
                <span>Iniciar repaso</span>
              </button>
            )}
          </div>
        </div>

        {reviewItems.length > 0 && (
          <div className="pt-4 border-t border-slate-200/70 space-y-2">
            <div className="flex items-center justify-between text-xs font-medium text-slate-600">
              <span>Distribución de la cola de repaso</span>
              <span className="font-mono tabular-nums">
                {reviewItems.length}{' '}
                {reviewItems.length === 1 ? 'término' : 'términos'}
              </span>
            </div>
            <SegmentedBar
              total={reviewItems.length}
              heightClass="h-2.5"
              segments={[
                {
                  label: 'Palabras',
                  value: wordCount,
                  colorClass: 'bg-amber-500',
                },
                {
                  label: 'Frases y expresiones',
                  value: phraseCount,
                  colorClass: 'bg-indigo-500',
                },
              ]}
            />
          </div>
        )}
      </section>

      {reviewItems.length === 0 ? (
        <section className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-3xl p-8 sm:p-12 text-center space-y-4">
          <CheckCircle2
            className="w-10 h-10 text-emerald-600 mx-auto"
            aria-hidden="true"
          />
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Tu cola de repaso está limpia
          </h2>
          <p className="text-slate-600 max-w-md mx-auto text-sm sm:text-base">
            No tienes errores pendientes por reforzar. Explora nuevos mundos de
            palabras y frases para seguir ampliando tu vocabulario.
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={onExploreWorlds}
              className="px-5 py-3 min-h-[44px] bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0"
            >
              Explorar mundos
            </button>
          </div>
        </section>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {reviewItems.map((item) => (
            <article
              key={item.id}
              className="bg-white/92 backdrop-blur-md border border-white/80 shadow-sm rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                  <span>{item.type === 'word' ? 'Palabra' : 'Frase'}</span>
                  <span aria-hidden="true">·</span>
                  <span>Nivel {item.level}</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.category}</span>
                </div>

                <div className="flex flex-wrap items-baseline gap-3">
                  <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
                    {item.displayEnglish ?? item.english}
                  </h2>
                  {item.phonetic && (
                    <span className="font-mono text-xs text-slate-500">
                      {item.phonetic}
                    </span>
                  )}
                </div>

                <p className="text-sm font-medium text-slate-700">
                  {item.spanish}
                </p>

                <p className="text-sm text-slate-600 leading-relaxed pt-1">
                  <span className="font-semibold text-amber-800">
                    Clave ortográfica:{' '}
                  </span>
                  {item.smartTip}
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  speakEnglish(item.displayEnglish ?? item.english, true)
                }
                className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-xl hover:bg-indigo-100 transition-colors whitespace-nowrap shrink-0 self-start"
              >
                <Volume2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Escuchar</span>
              </button>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
