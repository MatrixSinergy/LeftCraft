import { useEffect, useState } from 'react';
import { PlayStage } from './components/PlayStage';
import { ProgressView } from './components/ProgressView';
import { ReviewView } from './components/ReviewView';
import { RoundSummaryView } from './components/RoundSummaryView';
import { SidebarNav } from './components/SidebarNav';
import { Vocabulary1000View } from './components/Vocabulary1000View';
import { WorldsView } from './components/WorldsView';
import { ALL_CHALLENGES, CHALLENGES, getWorldById } from './data/curriculum';
import {
  ActiveRoundState,
  AppView,
  ChallengeItem,
  ContentFilter,
  PlayerProgress,
  RoundItemResult,
} from './types/game';
import {
  playRoundVictory,
  playTapError,
  playTapSuccess,
  playWordComplete,
  speakEnglish,
} from './utils/audio';
import { clearProgress, loadProgress, saveProgress } from './utils/storage';
import {
  buildLetterErrorFeedback,
  buildSlotsForChallenge,
  buildTilesForChallenge,
  findNextLetterCursor,
} from './utils/tileEngine';

function createRoundState(
  mode: ActiveRoundState['mode'],
  worldId: string | null,
  title: string,
  items: ChallengeItem[]
): ActiveRoundState {
  const first = items[0];
  const slots = buildSlotsForChallenge(first.english);
  const cursorIndex = findNextLetterCursor(slots, 0);

  return {
    mode,
    worldId,
    title,
    items,
    currentIndex: 0,
    slots,
    cursorIndex,
    tiles: buildTilesForChallenge(first),
    hintTier: 0,
    currentMistakes: 0,
    currentRevealUsed: false,
    itemCompleted: false,
    shakingTileId: null,
    feedback: {
      kind: 'idle',
      message:
        'Toca los bloques de letras en el orden correcto para construir la respuesta.',
    },
    results: [],
  };
}

export default function App() {
  const [progress, setProgress] = useState<PlayerProgress>(() => loadProgress());
  const [activeView, setActiveView] = useState<AppView>('WORLDS');
  const [filter, setFilter] = useState<ContentFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [round, setRound] = useState<ActiveRoundState | null>(null);
  const [lastRoundXp, setLastRoundXp] = useState(0);

  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  const accuracyPercent =
    progress.totalLettersTapped > 0
      ? Math.round(
          (progress.correctLettersFirstTry / progress.totalLettersTapped) * 100
        )
      : 100;

  const startWorldRound = (worldId: string, overrideFilter?: ContentFilter) => {
    const activeFilter = overrideFilter ?? filter;
    const world = getWorldById(worldId);
    const pool = CHALLENGES.filter(
      (c) =>
        c.worldId === worldId &&
        (activeFilter === 'all' || c.type === activeFilter)
    );
    if (pool.length === 0) return;

    const completedSet = new Set(progress.completedChallengeIds);
    const pending = pool.filter((c) => !completedSet.has(c.id));
    const items = (pending.length > 0 ? pending : pool).slice(0, 20);

    setProgress((prev) => ({ ...prev, lastWorldId: worldId }));
    setRound(
      createRoundState(
        'world',
        worldId,
        world ? world.title : 'Práctica',
        items
      )
    );
    setActiveView('PLAYING');
  };

  const startVocab1000Round = (title: string, items: ChallengeItem[]) => {
    if (items.length === 0) return;
    setRound(createRoundState('vocab1000', null, title, items));
    setActiveView('PLAYING');
  };

  const startQuickMixRound = () => {
    const completedSet = new Set(progress.completedChallengeIds);
    const pool = ALL_CHALLENGES.filter(
      (c) => filter === 'all' || c.type === filter
    );
    const uncompleted = pool.filter((c) => !completedSet.has(c.id));
    const selected = (uncompleted.length >= 6 ? uncompleted : pool).slice(0, 8);
    if (selected.length === 0) return;

    setRound(
      createRoundState('quick', null, 'Práctica rápida mixta', selected)
    );
    setActiveView('PLAYING');
  };

  const startReviewRound = () => {
    const reviewItems = ALL_CHALLENGES.filter((c) =>
      progress.reviewQueueIds.includes(c.id)
    );
    if (reviewItems.length === 0) return;

    setRound(
      createRoundState('review', null, 'Sesión de repaso', reviewItems)
    );
    setActiveView('PLAYING');
  };

  const handleQuickPlayAction = () => {
    if (round && activeView !== 'ROUND_SUMMARY') {
      setActiveView('PLAYING');
      return;
    }
    startQuickMixRound();
  };

  const handleSearchSubmit = (q: string) => {
    setSearchQuery(q);
    if (q.trim() && activeView !== 'VOCAB_1000') {
      setActiveView('VOCAB_1000');
    }
  };

  const completeChallengeAndUpdateProgress = (
    currentRound: ActiveRoundState,
    item: ChallengeItem,
    mistakes: number,
    revealUsed: boolean,
    hintTier: 0 | 1 | 2 | 3
  ): ActiveRoundState => {
    const displayEnglish = item.displayEnglish ?? item.english;
    const itemResult: RoundItemResult = {
      challengeId: item.id,
      english: displayEnglish,
      spanish: item.spanish,
      mistakes,
      hintsUsed: hintTier,
      usedRevealHint: revealUsed,
    };

    const hadIssues = mistakes > 0 || revealUsed;
    const earnedXp = Math.max(10, 25 - mistakes * 4 - (revealUsed ? 8 : 0));

    setProgress((prev) => {
      const nextCompleted = prev.completedChallengeIds.includes(item.id)
        ? prev.completedChallengeIds
        : [...prev.completedChallengeIds, item.id];

      let nextReview = [...prev.reviewQueueIds];
      if (hadIssues) {
        if (!nextReview.includes(item.id)) {
          nextReview.push(item.id);
        }
      } else {
        nextReview = nextReview.filter((id) => id !== item.id);
      }

      const nextStreak = hadIssues ? 0 : prev.currentStreak + 1;
      const nextBest = Math.max(prev.bestStreak, nextStreak);

      return {
        ...prev,
        xp: prev.xp + earnedXp,
        currentStreak: nextStreak,
        bestStreak: nextBest,
        completedChallengeIds: nextCompleted,
        reviewQueueIds: nextReview,
      };
    });

    playWordComplete(progress.soundEnabled);
    speakEnglish(displayEnglish, progress.soundEnabled);

    return {
      ...currentRound,
      itemCompleted: true,
      results: [...currentRound.results, itemResult],
      feedback: {
        kind: 'success',
        message:
          mistakes === 0 && !revealUsed
            ? `¡Perfecto! Completaste "${displayEnglish}" sin errores.`
            : `Completaste "${displayEnglish}".`,
      },
    };
  };

  const handleTapTile = (tileId: string) => {
    if (!round || round.itemCompleted) return;
    const item = round.items[round.currentIndex];
    const tile = round.tiles.find((t) => t.id === tileId);
    if (!item || !tile || tile.status !== 'available') return;

    const targetSlot = round.slots[round.cursorIndex];
    if (!targetSlot) return;

    const isCorrect = tile.letter === targetSlot.char;

    setProgress((prev) => ({
      ...prev,
      totalLettersTapped: prev.totalLettersTapped + 1,
      correctLettersFirstTry:
        prev.correctLettersFirstTry + (isCorrect ? 1 : 0),
    }));

    if (isCorrect) {
      playTapSuccess(progress.soundEnabled);

      const updatedSlots = round.slots.map((s) =>
        s.index === targetSlot.index ? { ...s, status: 'correct' as const } : s
      );
      const updatedTiles = round.tiles.map((t) =>
        t.id === tileId ? { ...t, status: 'used' as const } : t
      );
      const nextCursor = findNextLetterCursor(
        updatedSlots,
        targetSlot.index + 1
      );

      if (nextCursor === -1) {
        const completedState = completeChallengeAndUpdateProgress(
          {
            ...round,
            slots: updatedSlots,
            tiles: updatedTiles,
            cursorIndex: -1,
            shakingTileId: null,
          },
          item,
          round.currentMistakes,
          round.currentRevealUsed,
          round.hintTier
        );
        setRound(completedState);
      } else {
        setRound({
          ...round,
          slots: updatedSlots,
          tiles: updatedTiles,
          cursorIndex: nextCursor,
          shakingTileId: null,
          feedback: {
            kind: 'idle',
            message: `¡Bien! Letra '${tile.letter}' correcta. Continúa con la siguiente casilla.`,
          },
        });
      }
    } else {
      playTapError(progress.soundEnabled);
      const errorMsg = buildLetterErrorFeedback(
        targetSlot.char,
        tile.letter,
        item,
        round.slots,
        round.cursorIndex
      );

      setProgress((prev) => ({
        ...prev,
        reviewQueueIds: prev.reviewQueueIds.includes(item.id)
          ? prev.reviewQueueIds
          : [...prev.reviewQueueIds, item.id],
      }));

      setRound({
        ...round,
        currentMistakes: round.currentMistakes + 1,
        shakingTileId: tileId,
        feedback: {
          kind: 'error',
          message: errorMsg,
          tappedLetter: tile.letter,
        },
      });

      window.setTimeout(() => {
        setRound((curr) =>
          curr && curr.shakingTileId === tileId
            ? { ...curr, shakingTileId: null }
            : curr
        );
      }, 220);
    }
  };

  const handleRequestHint = (tier: 1 | 2 | 3) => {
    if (!round || round.itemCompleted) return;
    const item = round.items[round.currentIndex];
    if (!item) return;

    if (tier === 1) {
      setRound({
        ...round,
        hintTier: Math.max(round.hintTier, 1) as 0 | 1 | 2 | 3,
        feedback: {
          kind: 'hint',
          message: item.smartTip,
        },
      });
      return;
    }

    if (tier === 2) {
      const updatedTiles = round.tiles.map((t) =>
        t.isDistractor && t.status === 'available'
          ? { ...t, status: 'eliminated' as const }
          : t
      );
      setRound({
        ...round,
        hintTier: Math.max(round.hintTier, 2) as 0 | 1 | 2 | 3,
        tiles: updatedTiles,
        feedback: {
          kind: 'hint',
          message:
            'Distractores filtrados: ahora solo quedan activas las letras reales de la respuesta.',
        },
      });
      return;
    }

    if (tier === 3) {
      const targetSlot = round.slots[round.cursorIndex];
      if (!targetSlot) return;

      const matchingTile =
        round.tiles.find(
          (t) =>
            t.status === 'available' &&
            !t.isDistractor &&
            t.letter === targetSlot.char
        ) ||
        round.tiles.find(
          (t) => t.status === 'available' && t.letter === targetSlot.char
        );

      if (!matchingTile) return;

      playTapSuccess(progress.soundEnabled);

      const updatedSlots = round.slots.map((s) =>
        s.index === targetSlot.index ? { ...s, status: 'hinted' as const } : s
      );
      const updatedTiles = round.tiles.map((t) =>
        t.id === matchingTile.id ? { ...t, status: 'used' as const } : t
      );
      const nextCursor = findNextLetterCursor(
        updatedSlots,
        targetSlot.index + 1
      );

      if (nextCursor === -1) {
        const completedState = completeChallengeAndUpdateProgress(
          {
            ...round,
            slots: updatedSlots,
            tiles: updatedTiles,
            cursorIndex: -1,
            hintTier: 3,
            currentRevealUsed: true,
          },
          item,
          round.currentMistakes,
          true,
          3
        );
        setRound(completedState);
      } else {
        setRound({
          ...round,
          slots: updatedSlots,
          tiles: updatedTiles,
          cursorIndex: nextCursor,
          hintTier: 3,
          currentRevealUsed: true,
          feedback: {
            kind: 'hint',
            message: `Letra '${targetSlot.char}' revelada. ${item.smartTip}`,
          },
        });
      }
    }
  };

  const handleNextChallenge = () => {
    if (!round) return;
    const nextIdx = round.currentIndex + 1;

    if (nextIdx >= round.items.length) {
      const totalRoundXp = round.results.reduce(
        (sum, r) =>
          sum +
          Math.max(10, 25 - r.mistakes * 4 - (r.usedRevealHint ? 8 : 0)),
        0
      );
      setLastRoundXp(totalRoundXp);
      playRoundVictory(progress.soundEnabled);
      setActiveView('ROUND_SUMMARY');
      return;
    }

    const nextItem = round.items[nextIdx];
    const nextSlots = buildSlotsForChallenge(nextItem.english);
    const nextCursor = findNextLetterCursor(nextSlots, 0);

    setRound({
      ...round,
      currentIndex: nextIdx,
      slots: nextSlots,
      cursorIndex: nextCursor,
      tiles: buildTilesForChallenge(nextItem),
      hintTier: 0,
      currentMistakes: 0,
      currentRevealUsed: false,
      itemCompleted: false,
      shakingTileId: null,
      feedback: {
        kind: 'idle',
        message:
          'Toca los bloques de letras en el orden correcto para construir la respuesta.',
      },
    });
  };

  const handleReplayCurrentRound = () => {
    if (!round) return;
    setRound(
      createRoundState(round.mode, round.worldId, round.title, round.items)
    );
    setActiveView('PLAYING');
  };

  const handleToggleSound = () => {
    setProgress((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  };

  const handleResetProgress = () => {
    const fresh = clearProgress();
    setProgress(fresh);
    setRound(null);
  };

  return (
    <div className="min-h-screen bg-diffused-canvas text-slate-900">
      <div className="max-w-7xl mx-auto p-3 sm:p-5 lg:p-6 flex flex-col lg:flex-row gap-5 lg:gap-6 items-start">
        <SidebarNav
          activeView={activeView}
          progress={progress}
          hasActiveRound={Boolean(round && activeView !== 'ROUND_SUMMARY')}
          searchQuery={searchQuery}
          onSearchSubmit={handleSearchSubmit}
          onNavigate={setActiveView}
          onQuickPlay={handleQuickPlayAction}
          onStartWorld={(worldId) => startWorldRound(worldId)}
          onToggleSound={handleToggleSound}
        />

        <div className="flex-1 w-full min-w-0 flex flex-col min-h-[calc(100vh-3rem)]">
          <main className="flex-1 w-full min-w-0">
            {activeView === 'WORLDS' && (
              <WorldsView
                progress={progress}
                filter={filter}
                onChangeFilter={setFilter}
                onStartWorld={(worldId) => startWorldRound(worldId)}
                onStartQuickMix={startQuickMixRound}
                onOpenVocab1000={() => setActiveView('VOCAB_1000')}
                onOpenReview={() => setActiveView('REVIEW')}
              />
            )}

            {activeView === 'VOCAB_1000' && (
              <Vocabulary1000View
                progress={progress}
                externalSearchQuery={searchQuery}
                onStartRound={startVocab1000Round}
              />
            )}

            {activeView === 'PLAYING' && round && (
              <PlayStage
                round={round}
                currentStreak={progress.currentStreak}
                accuracyPercent={accuracyPercent}
                soundEnabled={progress.soundEnabled}
                onToggleSound={handleToggleSound}
                onExitToWorlds={() =>
                  setActiveView(
                    round.mode === 'vocab1000' ? 'VOCAB_1000' : 'WORLDS'
                  )
                }
                onTapTile={handleTapTile}
                onRequestHint={handleRequestHint}
                onNextChallenge={handleNextChallenge}
              />
            )}

            {activeView === 'ROUND_SUMMARY' && round && (
              <RoundSummaryView
                title={round.title}
                results={round.results}
                xpEarned={lastRoundXp}
                reviewCount={progress.reviewQueueIds.length}
                onReplayRound={handleReplayCurrentRound}
                onPracticeMistakes={startReviewRound}
                onBackToWorlds={() =>
                  setActiveView(
                    round.mode === 'vocab1000' ? 'VOCAB_1000' : 'WORLDS'
                  )
                }
              />
            )}

            {activeView === 'REVIEW' && (
              <ReviewView
                reviewQueueIds={progress.reviewQueueIds}
                onStartReviewSession={startReviewRound}
                onExploreWorlds={() => setActiveView('WORLDS')}
              />
            )}

            {activeView === 'STATS' && (
              <ProgressView
                progress={progress}
                onStartWorld={(worldId) => startWorldRound(worldId, 'all')}
                onOpenVocab1000={() => setActiveView('VOCAB_1000')}
                onResetProgress={handleResetProgress}
              />
            )}
          </main>

          <footer className="mt-8 pt-4 border-t border-slate-300/50 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-600">
            <span>LetraCraft · Aprendizaje de inglés letra por letra</span>
            <span>Progreso guardado localmente en este navegador</span>
          </footer>
        </div>
      </div>
    </div>
  );
}
