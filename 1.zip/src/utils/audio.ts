let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

function playTone(
  frequency: number,
  durationSec: number,
  type: OscillatorType = 'sine',
  gainPeak = 0.08,
  delaySec = 0
): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  const start = ctx.currentTime + delaySec;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(frequency, start);

  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(gainPeak, start + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + durationSec);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(start);
  osc.stop(start + durationSec + 0.02);
}

export function playTapSuccess(enabled: boolean): void {
  if (!enabled) return;
  playTone(587.33, 0.11, 'triangle', 0.07, 0);
  playTone(880, 0.14, 'sine', 0.06, 0.045);
}

export function playTapError(enabled: boolean): void {
  if (!enabled) return;
  playTone(210, 0.13, 'triangle', 0.07, 0);
  playTone(175, 0.15, 'sine', 0.06, 0.055);
}

export function playWordComplete(enabled: boolean): void {
  if (!enabled) return;
  playTone(523.25, 0.12, 'triangle', 0.07, 0);
  playTone(659.25, 0.12, 'triangle', 0.07, 0.07);
  playTone(783.99, 0.18, 'sine', 0.08, 0.14);
}

export function playRoundVictory(enabled: boolean): void {
  if (!enabled) return;
  playTone(523.25, 0.14, 'triangle', 0.07, 0);
  playTone(659.25, 0.14, 'triangle', 0.07, 0.09);
  playTone(783.99, 0.14, 'triangle', 0.07, 0.18);
  playTone(1046.5, 0.28, 'sine', 0.09, 0.27);
}

export function speakEnglish(text: string, enabled = true, rate = 0.92): void {
  if (!enabled || typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return;
  }

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.toLowerCase());
    utterance.lang = 'en-US';
    utterance.rate = rate;

    const voices = window.speechSynthesis.getVoices();
    const preferred =
      voices.find((v) => v.lang.startsWith('en-US')) ||
      voices.find((v) => v.lang.startsWith('en'));
    if (preferred) {
      utterance.voice = preferred;
    }

    window.speechSynthesis.speak(utterance);
  } catch {
    // Graceful no-op if speech synthesis is blocked
  }
}
