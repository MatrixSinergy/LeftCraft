import { ChallengeItem, LetterSlot, TileItem } from '../types/game';

export function buildSlotsForChallenge(english: string): LetterSlot[] {
  const normalized = english.toUpperCase().trim();
  const slots: LetterSlot[] = [];
  let wordIndex = 0;

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    const isSpace = char === ' ';
    const isSeparator = char === '-' || char === "'";

    if (isSpace) {
      wordIndex += 1;
    }

    slots.push({
      index: i,
      char,
      isSpace,
      isSeparator,
      status: isSeparator ? 'correct' : 'pending',
      wordIndex,
    });
  }

  return slots;
}

export function findNextLetterCursor(slots: LetterSlot[], startFrom = 0): number {
  for (let i = startFrom; i < slots.length; i++) {
    if (!slots[i].isSpace && !slots[i].isSeparator && slots[i].status === 'pending') {
      return i;
    }
  }
  return -1;
}

function shuffleArray<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function buildTilesForChallenge(item: ChallengeItem): TileItem[] {
  const letters = item.english
    .toUpperCase()
    .split('')
    .filter((ch) => ch >= 'A' && ch <= 'Z');

  const neededSet = new Set(letters);
  const maxDistractors = letters.length > 13 ? 2 : 4;
  const validDistractors = item.distractors
    .map((d) => d.toUpperCase())
    .filter((d) => d >= 'A' && d <= 'Z' && d.length === 1 && !neededSet.has(d))
    .slice(0, maxDistractors);

  const tiles: TileItem[] = [
    ...letters.map((letter, idx) => ({
      id: `${item.id}-req-${idx}-${letter}`,
      letter,
      isDistractor: false,
      status: 'available' as const,
    })),
    ...validDistractors.map((letter, idx) => ({
      id: `${item.id}-dist-${idx}-${letter}`,
      letter,
      isDistractor: true,
      status: 'available' as const,
    })),
  ];

  return shuffleArray(tiles);
}

const VOWELS = new Set(['A', 'E', 'I', 'O', 'U']);

export function buildLetterErrorFeedback(
  expectedChar: string,
  tappedChar: string,
  item: ChallengeItem,
  slots: LetterSlot[],
  cursorIndex: number
): string {
  const expected = expectedChar.toUpperCase();
  const tapped = tappedChar.toUpperCase();

  // Check if it's a repeated previous letter (double letter pattern)
  const prevSlot = cursorIndex > 0 ? slots[cursorIndex - 1] : null;
  if (prevSlot && !prevSlot.isSpace && !prevSlot.isSeparator && prevSlot.char === expected) {
    return `Casi ('${tapped}'): aquí va una letra doble (${expected}${expected}).`;
  }

  // Consonant pair confusions common for Spanish learners
  if ((expected === 'V' && tapped === 'B') || (expected === 'B' && tapped === 'V')) {
    return `Ojo con '${tapped}': en inglés esta palabra distingue entre B y V — prueba la otra.`;
  }

  if ((expected === 'C' && (tapped === 'K' || tapped === 'S')) || (expected === 'K' && tapped === 'C')) {
    return `Confusión frecuente con '${tapped}': este sonido se escribe aquí con otra consonante (C/K/S).`;
  }

  if ((expected === 'W' && tapped === 'U') || (expected === 'U' && tapped === 'W')) {
    return `Casi ('${tapped}'): en inglés el sonido suave "u" al inicio o cierre suele escribirse con W o U.`;
  }

  if ((expected === 'J' && tapped === 'Y') || (expected === 'Y' && tapped === 'J')) {
    return `Atención con '${tapped}': recuerda la diferencia ortográfica entre J e Y en inglés.`;
  }

  if (expected === 'H' && VOWELS.has(tapped)) {
    return `Cuidado: antes de la vocal falta una 'H' (muda o aspirada).`;
  }

  if (VOWELS.has(expected) && VOWELS.has(tapped)) {
    return `Vocal distinta ('${tapped}'): en inglés la pronunciación engaña; prueba otra vocal.`;
  }

  const letterPos = slots
    .slice(0, cursorIndex + 1)
    .filter((s) => !s.isSpace && !s.isSeparator).length;
  return `'${tapped}' no corresponde a la letra ${letterPos}. ${item.smartTip}`;
}
