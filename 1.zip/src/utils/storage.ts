import { PlayerProgress } from '../types/game';

const STORAGE_KEY = 'letracraft_progress_v1';

export const DEFAULT_PROGRESS: PlayerProgress = {
  xp: 0,
  currentStreak: 0,
  bestStreak: 0,
  totalLettersTapped: 0,
  correctLettersFirstTry: 0,
  completedChallengeIds: [],
  reviewQueueIds: [],
  soundEnabled: true,
  lastWorldId: 'world-1',
};

export function loadProgress(): PlayerProgress {
  if (typeof window === 'undefined') return DEFAULT_PROGRESS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as Partial<PlayerProgress>;
    return {
      xp: typeof parsed.xp === 'number' ? parsed.xp : 0,
      currentStreak: typeof parsed.currentStreak === 'number' ? parsed.currentStreak : 0,
      bestStreak: typeof parsed.bestStreak === 'number' ? parsed.bestStreak : 0,
      totalLettersTapped:
        typeof parsed.totalLettersTapped === 'number' ? parsed.totalLettersTapped : 0,
      correctLettersFirstTry:
        typeof parsed.correctLettersFirstTry === 'number' ? parsed.correctLettersFirstTry : 0,
      completedChallengeIds: Array.isArray(parsed.completedChallengeIds)
        ? parsed.completedChallengeIds
        : [],
      reviewQueueIds: Array.isArray(parsed.reviewQueueIds) ? parsed.reviewQueueIds : [],
      soundEnabled: typeof parsed.soundEnabled === 'boolean' ? parsed.soundEnabled : true,
      lastWorldId: typeof parsed.lastWorldId === 'string' ? parsed.lastWorldId : 'essentials',
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export function saveProgress(progress: PlayerProgress): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // Ignore storage quota errors
  }
}

export function clearProgress(): PlayerProgress {
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore
    }
  }
  return { ...DEFAULT_PROGRESS };
}
