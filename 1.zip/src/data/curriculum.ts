import { ChallengeItem, WorldInfo } from '../types/game';
import { INTERMEDIATE_1000_CHALLENGES } from './intermediate1000';

export const WORLDS: WorldInfo[] = [
  {
    id: 'world-1',
    title: 'Mundo 1 · Bases y Viajes',
    subtitle:
      'Palabras #1 a #250 del vocabulario intermedio: viajes, hogar, clima y expresiones cotidianas.',
    levelRange: 'Intermedio · Parte 1',
    accentColor: 'indigo',
    imagePath: '/src/assets/images/world_essentials_1795276269221.jpg',
  },
  {
    id: 'world-2',
    title: 'Mundo 2 · Vida y Rutina',
    subtitle:
      'Palabras #251 a #500: salud, ciudad, verbos compuestos y situaciones del día a día.',
    levelRange: 'Intermedio · Parte 2',
    accentColor: 'emerald',
    imagePath: '/src/assets/images/world_phrases_1795276270329.jpg',
  },
  {
    id: 'world-3',
    title: 'Mundo 3 · Acción y Entorno',
    subtitle:
      'Palabras #501 a #750: trabajo, entretenimiento, naturaleza y comunicación diaria.',
    levelRange: 'Intermedio · Parte 3',
    accentColor: 'amber',
    imagePath: '/src/assets/images/world_travel_1795276270820.jpg',
  },
  {
    id: 'world-4',
    title: 'Mundo 4 · Expresión Fluida',
    subtitle:
      'Palabras #751 a #1000: conceptos avanzados, opiniones y expresiones idiomáticas.',
    levelRange: 'Intermedio · Parte 4',
    accentColor: 'rose',
    imagePath: '/src/assets/images/world_conversation_1795276270163.jpg',
  },
];

export const CHALLENGES: ChallengeItem[] = INTERMEDIATE_1000_CHALLENGES;

export const ALL_CHALLENGES: ChallengeItem[] = INTERMEDIATE_1000_CHALLENGES;

export function getWorldById(worldId: string): WorldInfo | undefined {
  return WORLDS.find((w) => w.id === worldId);
}
