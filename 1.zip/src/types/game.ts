export type ChallengeType = 'word' | 'phrase';

export type CefrLevel = 'A1' | 'A2' | 'B1';

export type AppView =
  | 'WORLDS'
  | 'VOCAB_1000'
  | 'PLAYING'
  | 'ROUND_SUMMARY'
  | 'REVIEW'
  | 'STATS';

export type ContentFilter = 'all' | 'word' | 'phrase';

export interface ChallengeItem {
  id: string;
  worldId: string;
  type: ChallengeType;
  level: CefrLevel;
  category: string;
  english: string;
  displayEnglish?: string;
  spanish: string;
  phonetic?: string;
  contextExample?: string;
  contextTranslation?: string;
  smartTip: string;
  distractors: string[];
}

export interface WorldInfo {
  id: string;
  title: string;
  subtitle: string;
  levelRange: string;
  accentColor: 'indigo' | 'emerald' | 'amber' | 'rose';
  imagePath: string;
}

export type SlotStatus = 'pending' | 'correct' | 'hinted';

export interface LetterSlot {
  index: number;
  char: string;
  isSpace: boolean;
  isSeparator: boolean;
  status: SlotStatus;
  wordIndex: number;
}

export type TileStatus = 'available' | 'used' | 'eliminated';

export interface TileItem {
  id: string;
  letter: string;
  isDistractor: boolean;
  status: TileStatus;
}

export type FeedbackState =
  | { kind: 'idle'; message: string }
  | { kind: 'error'; message: string; tappedLetter: string }
  | { kind: 'hint'; message: string }
  | { kind: 'success'; message: string };

export interface RoundItemResult {
  challengeId: string;
  english: string;
  spanish: string;
  mistakes: number;
  hintsUsed: number;
  usedRevealHint: boolean;
}

export interface ActiveRoundState {
  mode: 'world' | 'vocab1000' | 'review' | 'quick';
  worldId: string | null;
  title: string;
  items: ChallengeItem[];
  currentIndex: number;
  slots: LetterSlot[];
  cursorIndex: number;
  tiles: TileItem[];
  hintTier: 0 | 1 | 2 | 3;
  currentMistakes: number;
  currentRevealUsed: boolean;
  itemCompleted: boolean;
  shakingTileId: string | null;
  feedback: FeedbackState;
  results: RoundItemResult[];
}

export interface PlayerProgress {
  xp: number;
  currentStreak: number;
  bestStreak: number;
  totalLettersTapped: number;
  correctLettersFirstTry: number;
  completedChallengeIds: string[];
  reviewQueueIds: string[];
  soundEnabled: boolean;
  lastWorldId: string;
}
